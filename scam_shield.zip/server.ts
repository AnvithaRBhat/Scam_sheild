import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';
import { ScanMode } from './src/types/scamshield';
import { getModelEvaluation } from './server/mlClassifier';
import { createScanId, runBaselineAnalysis } from './server/scamAnalyzer';
import { analyzeWithGeminiHybrid } from './server/geminiService';

const PORT = Number(process.env.PORT) || 3000;
const VALID_MODES = new Set<ScanMode>(['sms', 'email', 'url']);

function sanitizeString(value: unknown, maxLen: number): string {
  if (typeof value !== 'string') return '';
  // Strip null bytes & normalize line endings without altering printable URL/text tokens
  return value.replace(/\0/g, '').replace(/\r\n/g, '\n').trim().slice(0, maxLen);
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '64kb' }));

  // Basic security headers for untrusted input processing app
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  app.get('/api/health', (_req, res) => {
    const apiKey = process.env.GEMINI_API_KEY?.trim();
    const aiConfigured = Boolean(apiKey && apiKey !== 'MY_GEMINI_API_KEY');
    res.json({
      status: 'ok',
      aiConfigured,
      engine: aiConfigured ? 'gemini-ai-hybrid' : 'baseline-ml',
    });
  });

  app.get('/api/model-info', (_req, res) => {
    res.json(getModelEvaluation());
  });

  app.post('/api/scan', async (req, res) => {
    try {
      const mode = req.body?.mode as ScanMode;
      if (!VALID_MODES.has(mode)) {
        res.status(400).json({ error: 'Invalid scan mode. Choose sms, email, or url.' });
        return;
      }

      const content = sanitizeString(req.body?.content, 8000);
      const subject = sanitizeString(req.body?.subject, 300);
      const sender = sanitizeString(req.body?.sender, 240);

      if (!content || content.length < 3) {
        res.status(400).json({
          error:
            mode === 'url'
              ? 'Please enter a valid URL to inspect (at least 4 characters).'
              : 'Please paste a message or email body with at least 3 characters.',
        });
        return;
      }

      if (mode === 'url' && /\s/.test(content)) {
        res.status(400).json({
          error: 'URLs cannot contain spaces. Use the SMS or Email scanner if analyzing a full message.',
        });
        return;
      }

      // Privacy guarantee: never log user-submitted message contents, subjects, or URLs
      const scanId = createScanId();
      const baseline = runBaselineAnalysis({ mode, content, subject, sender });
      const result = await analyzeWithGeminiHybrid(
        scanId,
        { mode, content, subject, sender },
        baseline
      );

      res.json(result);
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Unexpected server error';
      console.error(`[SCAMSHIELD] Scan request failed: ${msg.slice(0, 80)}`);
      res.status(500).json({ error: 'Unable to complete security analysis right now. Please try again.' });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`scam_shield server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start scam_shield server:', err);
  process.exit(1);
});
