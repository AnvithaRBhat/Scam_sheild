# scam_shield

**Tagline:** *Think Before You Click. Stay One Step Ahead.*
**Identity:** *Don't just detect scams. Understand them. Prevent them. Stay protected.*

scam_shield is a full-stack, explainable cybersecurity web application designed to help everyday users inspect suspicious SMS messages, emails, and URLs—and understand the reasoning and social-engineering tactics behind every alert.

---

## Problem Statement

Modern phishing, smishing, and impersonation scams succeed because everyday users are forced to make split-second trust decisions on unfamiliar messages and lookalike links. Conventional spam filters return opaque binary verdicts ("Spam" / "Blocked") without teaching people *why* a message is risky or *how* to recognize future variations.

scam_shield bridges that gap by pairing deterministic lexical/URL security checks and a real evaluated machine-learning baseline with explainable AI reasoning and a plain-English **Understand the Threat** education briefing.

---

## Key Features

### 1. Three Dedicated Scanners
- **SMS & Message Scanner:** Inspects SMS, WhatsApp, and direct messages for smishing lures, artificial urgency, OTP/credential harvesting, and embedded suspicious links.
- **Email Scanner:** Evaluates optional sender display-name/domain mismatches, misleading subject lines, BEC (Business Email Compromise) secrecy cues, and phishing copy.
- **URL Scanner:** Performs purely **static structural analysis**—checking protocol (explicitly warning that HTTPS alone does not prove safety), raw IP hosts, punycode (`xn--`) homographs, `@` authority masking, Levenshtein brand typosquatting, subdomain stacking, and elevated-risk TLDs. **Submitted URLs are never visited, opened, or executed.**

### 2. Explainable Risk Dashboard
- **Classification & Estimated Risk Score (`0–100`):** Categorizes inputs as `Likely Safe`, `Suspicious`, `Potential Phishing`, or `Spam` alongside `Low` / `Medium` / `High` risk levels and an explicit disclaimer that scores are estimates rather than guaranteed probabilities.
- **Interactive Highlighted Text:** Highlights exact verbatim phrases and URL tokens inside the submitted content with click-to-inspect explanations.
- **Detected Evidence vs. Uncertain Indications:** Separates concrete observed red flags from ambiguous heuristic cues so the system never invents reasons without evidence.
- **Actionable Next Steps & Export:** Downloadable `.txt` and `.json` reports plus one-click copy.

### 3. Unique Feature: "Understand the Threat"
Translates every scan into non-technical education across five areas:
1. Scam type represented
2. How the suspicious technique works
3. What the sender may be trying to achieve
4. Which personal or financial information to protect
5. How to prevent similar scams in the future

### 4. Privacy, Controls & Awareness
- **Opt-In Local History:** Scan history is stored strictly in browser `localStorage` only when enabled, with one-click clear and disable controls. Zero server-side message logging or disk persistence.
- **Dark & Light Mode:** Full dual-theme support.
- **Cybersecurity Awareness Playbooks:** Interactive guides covering Smishing, Executive Impersonation, Lookalike Domains, and OTP Traps.

---

## Technology Stack

- **Frontend:** React 19, TypeScript, Tailwind CSS v4, Lucide Icons
- **Backend:** Node.js, Express (`server.ts`)
- **AI Engine:** Google Gemini (`@google/genai` SDK, `gemini-4-hydrogen` with structured JSON schema)
- **Baseline ML Engine:** Custom TypeScript Multinomial Naive Bayes (Unigram + Bigram, Laplace Smoothing) with deterministic 80/20 held-out test-split evaluation

---

## Architecture

```
+-----------------------+       POST /api/scan        +----------------------------+
|  React + Tailwind UI  | --------------------------> |  Express API (server.ts)   |
|  - SMS / Email / URL  |                             |  - Input sanitization      |
|  - Highlighted Spans  |                             |  - Zero-logging guarantee  |
|  - Understand Threat  |                             +-------------+--------------+
|  - Opt-in History     |                                           |
+-----------------------+                                           v
                                                      +----------------------------+
                                                      | Deterministic Security     |
                                                      | & ML Baseline Layer        |
                                                      | - URL lexical/homograph    |
                                                      | - Brand Levenshtein check  |
                                                      | - Naive Bayes classifier   |
                                                      +-------------+--------------+
                                                                    |
                                           If GEMINI_API_KEY active | Otherwise transparent
                                                                    v baseline-ml response
                                                      +----------------------------+
                                                      | Gemini Hybrid Reasoning    |
                                                      | - Grounded JSON schema     |
                                                      | - Evidence vs uncertainty  |
                                                      +----------------------------+
```

---

## Local Setup & Installation

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Configure environment variables (optional for hybrid AI):**
   Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
   Set `GEMINI_API_KEY` in `.env` if you want Gemini contextual reasoning alongside the baseline engine. If omitted, scam_shield automatically runs transparently in `baseline-ml` offline mode.

3. **Run in development mode:**
   ```bash
   npm run dev
   ```
   Open `http://localhost:3000`.

4. **Build and run in production:**
   ```bash
   npm run build
   npm start
   ```

---

## Limitations & Future Scope

- **Current Limitations:**
  - The Naive Bayes baseline model is trained on a compact curated benchmark dataset; unseen phrasing relies on lexical rules or the Gemini hybrid layer.
  - URL inspection is purely lexical/structural and does not perform live WHOIS domain age queries or external threat-feed lookups.
  - Automated risk scores are preliminary indicators and never guarantee 100% detection accuracy.
- **Future Scope:**
  - Integration with vetted threat-intelligence feeds (e.g., Google Safe Browsing / PhishTank) via server-side APIs.
  - Multi-language scam detection and email `.eml` header DKIM/SPF/DMARC signature verification.
  - Optional browser extension for pre-click link previews.
