import { ModelEvaluationInfo } from '../src/types/scamshield';

type BinaryLabel = 'threat' | 'safe';

interface TrainingDocument {
  text: string;
  label: BinaryLabel;
  subtype: 'phishing' | 'spam' | 'safe';
}

const LABELED_DATASET: TrainingDocument[] = [
  // Phishing / Smishing (28)
  { text: 'urgent your chase bank account has been suspended verify identity within 24 hours login link', label: 'threat', subtype: 'phishing' },
  { text: 'usps package cannot be delivered incomplete address pay redelivery fee immediately track link', label: 'threat', subtype: 'phishing' },
  { text: 'irs tax refund pending confirm social security number and bank routing details today', label: 'threat', subtype: 'phishing' },
  { text: 'apple id locked due to suspicious sign in attempt reset password immediately to avoid closure', label: 'threat', subtype: 'phishing' },
  { text: 'netflix billing failed update payment card details now to prevent account termination', label: 'threat', subtype: 'phishing' },
  { text: 'paypal unauthorized charge 489 dollars verify password and card info to cancel transaction', label: 'threat', subtype: 'phishing' },
  { text: 'dhl express parcel held at customs pay clearance fee via link before return', label: 'threat', subtype: 'phishing' },
  { text: 'microsoft 365 password expires today click here to keep same password sign in', label: 'threat', subtype: 'phishing' },
  { text: 'bank of america unusual login detected confirm one time passcode otp immediately', label: 'threat', subtype: 'phishing' },
  { text: 'amazon order 940 dollars iphone placed click link to dispute and verify credentials', label: 'threat', subtype: 'phishing' },
  { text: 'coinbase wallet security alert verify seed phrase within 12 hours or funds frozen', label: 'threat', subtype: 'phishing' },
  { text: 'ceo urgent favor stuck in meeting buy apple gift cards scratch pin codes email asap', label: 'threat', subtype: 'phishing' },
  { text: 'hr payroll direct deposit update confirm employee portal login and bank account number', label: 'threat', subtype: 'phishing' },
  { text: 'wells fargo debit card restricted call toll free or verify pin online immediately', label: 'threat', subtype: 'phishing' },
  { text: 'fedex missed delivery schedule redelivery confirm credit card billing address', label: 'threat', subtype: 'phishing' },
  { text: 'instagram copyright violation appeal within 24 hours enter password to prevent deletion', label: 'threat', subtype: 'phishing' },
  { text: 'whatsapp verification code requested share 6 digit pin to restore account access', label: 'threat', subtype: 'phishing' },
  { text: 'docusign invoice document awaiting signature sign in with corporate email credentials', label: 'threat', subtype: 'phishing' },
  { text: 'binance withdrawal initiated confirm kyc identity upload passport photo immediately', label: 'threat', subtype: 'phishing' },
  { text: 'medicare benefits suspended verify member id and date of birth right away', label: 'threat', subtype: 'phishing' },
  { text: 'dropbox shared confidential bonus file enter email password to view document', label: 'threat', subtype: 'phishing' },
  { text: 'citibank fraud alert reply yes or click secure verification link to unlock card', label: 'threat', subtype: 'phishing' },
  { text: 'toll road unpaid balance 4.50 avoid late penalty fee pay immediately online', label: 'threat', subtype: 'phishing' },
  { text: 'venmo payment on hold send verification deposit to release funds to your balance', label: 'threat', subtype: 'phishing' },
  { text: 'google workspace storage full upgrade billing credit card or lose all emails today', label: 'threat', subtype: 'phishing' },
  { text: 'geek squad auto renewal 399 charged today call support number for immediate refund', label: 'threat', subtype: 'phishing' },
  { text: 'linkedin security warning suspicious session click url to reauthenticate account', label: 'threat', subtype: 'phishing' },
  { text: 'adobe cloud invoice overdue download attached form and enter credentials', label: 'threat', subtype: 'phishing' },

  // Spam / Financial Scams (16)
  { text: 'congratulations you won 500 walmart gift card claim prize before midnight tap link', label: 'threat', subtype: 'spam' },
  { text: 'guaranteed crypto investment double your bitcoin in 48 hours zero risk profit', label: 'threat', subtype: 'spam' },
  { text: 'work from home earn 3500 weekly no experience required message whatsapp recruiter', label: 'threat', subtype: 'spam' },
  { text: 'preapproved personal loan 25000 low interest bad credit ok instant cash deposit', label: 'threat', subtype: 'spam' },
  { text: 'exclusive vip casino bonus free spins claim 1000 reward today only', label: 'threat', subtype: 'spam' },
  { text: 'you have unclaimed lottery winnings wire processing fee to release payout', label: 'threat', subtype: 'spam' },
  { text: 'hot singles in your area waiting to chat click private profile link now', label: 'threat', subtype: 'spam' },
  { text: 'urgent debt forgiveness government grant apply free money never pay back', label: 'threat', subtype: 'spam' },
  { text: 'miracle weight loss supplement doctors hate this 80 percent off limited stock', label: 'threat', subtype: 'spam' },
  { text: 'secret stock alert guaranteed 500 percent return buy before market opens tomorrow', label: 'threat', subtype: 'spam' },
  { text: 'mystery shopper job opportunity deposit check and wire remaining balance back', label: 'threat', subtype: 'spam' },
  { text: 'free iphone 16 giveaway complete short survey pay only shipping fee today', label: 'threat', subtype: 'spam' },
  { text: 'boost credit score 200 points overnight guaranteed legal loophole call now', label: 'threat', subtype: 'spam' },
  { text: 'final notice car extended warranty expiring renew protection plan immediately', label: 'threat', subtype: 'spam' },
  { text: 'flash sale luxury watches 95 percent discount replica limited time offer', label: 'threat', subtype: 'spam' },
  { text: 'crypto airdrop claim free tokens connect wallet sign approval transaction now', label: 'threat', subtype: 'spam' },

  // Legitimate / Safe Communications (36)
  { text: 'hi maya friendly reminder from oakridge dental cleaning appointment thursday 1030 am reply c to confirm', label: 'safe', subtype: 'safe' },
  { text: 'your requested library book is ready for pickup at central branch through november 20', label: 'safe', subtype: 'safe' },
  { text: 'hey are we still meeting for coffee around 3pm near the train station today', label: 'safe', subtype: 'safe' },
  { text: 'your verification code is 482910 do not share this code with anyone including employees', label: 'safe', subtype: 'safe' },
  { text: 'meeting notes from tuesday product review attached please share feedback before friday', label: 'safe', subtype: 'safe' },
  { text: 'thanks for your order at greenleaf books your receipt total is 24.50 shipping in 2 days', label: 'safe', subtype: 'safe' },
  { text: 'mom called earlier asking if we are bringing salad to sunday family dinner', label: 'safe', subtype: 'safe' },
  { text: 'reminder your monthly rent payment of 1450 was received thank you', label: 'safe', subtype: 'safe' },
  { text: 'team standup moved to conference room b at 930 am tomorrow morning', label: 'safe', subtype: 'safe' },
  { text: 'happy birthday alex hope you have a wonderful celebration with friends tonight', label: 'safe', subtype: 'safe' },
  { text: 'your flight check in opens 24 hours before departure view boarding pass in airline app', label: 'safe', subtype: 'safe' },
  { text: 'prescription ready for pickup at main street pharmacy hours 9am to 7pm', label: 'safe', subtype: 'safe' },
  { text: 'thank you for attending our cybersecurity awareness webinar slides are posted on our portal', label: 'safe', subtype: 'safe' },
  { text: 'your utility bill statement for october is available in your online customer portal', label: 'safe', subtype: 'safe' },
  { text: 'can you review the pull request when you get a free moment after lunch', label: 'safe', subtype: 'safe' },
  { text: 'school bus route 14 is running 10 minutes behind schedule due to morning rain', label: 'safe', subtype: 'safe' },
  { text: 'confirmation your gym membership class reservation for yoga at 6pm is booked', label: 'safe', subtype: 'safe' },
  { text: 'quarterly newsletter read our latest engineering blog post on distributed caching', label: 'safe', subtype: 'safe' },
  { text: 'driver sarah is 4 minutes away in a blue civic license plate ending 742', label: 'safe', subtype: 'safe' },
  { text: 'please bring your photo id to the front desk when arriving for your interview', label: 'safe', subtype: 'safe' },
  { text: 'doctor patel office confirming your annual physical exam on monday november 18', label: 'safe', subtype: 'safe' },
  { text: 'great catching up yesterday let me know next week when you are free for lunch', label: 'safe', subtype: 'safe' },
  { text: 'city water maintenance scheduled wednesday between 1pm and 3pm on maple avenue', label: 'safe', subtype: 'safe' },
  { text: 'order shipped via ground carrier tracking number available inside your account orders page', label: 'safe', subtype: 'safe' },
  { text: 'security notice you added a new hardware passkey to your profile if this was you no action needed', label: 'safe', subtype: 'safe' },
  { text: 'your podcast episode download finished listening offline mode ready', label: 'safe', subtype: 'safe' },
  { text: 'calendar invite design critique session wednesday 2pm to 3pm video link inside', label: 'safe', subtype: 'safe' },
  { text: 'vet clinic reminder luna annual vaccination due next month call front desk to book', label: 'safe', subtype: 'safe' },
  { text: 'receipt for 8.75 coffee shop downtown thank you for visiting today', label: 'safe', subtype: 'safe' },
  { text: 'weather advisory heavy rain expected overnight allow extra commute time tomorrow', label: 'safe', subtype: 'safe' },
  { text: 'volunteer schedule updated for saturday morning park cleanup bring gloves', label: 'safe', subtype: 'safe' },
  { text: 'project timeline document shared by elena read access granted for team members', label: 'safe', subtype: 'safe' },
  { text: 'how to recognize and avoid phishing scams official consumer protection guide', label: 'safe', subtype: 'safe' },
  { text: 'university registrar reminder spring semester course registration opens monday morning', label: 'safe', subtype: 'safe' },
  { text: 'auto mechanic update brake pad inspection complete car ready for pickup before 5pm', label: 'safe', subtype: 'safe' },
  { text: 'grocery delivery left at front porch per your instructions have a great evening', label: 'safe', subtype: 'safe' },
];

const STOPWORDS = new Set([
  'the', 'a', 'an', 'and', 'or', 'to', 'of', 'in', 'on', 'at', 'is', 'are', 'was',
  'for', 'with', 'that', 'this', 'it', 'by', 'as', 'be', 'from', 'if', 'we', 'you', 'your',
]);

export function tokenize(input: string): string[] {
  const cleaned = input
    .toLowerCase()
    .replace(/https?:\/\/[^\s]+/g, (url) => {
      const hostParts = url.replace(/^https?:\/\//, '').split(/[/?#.:-]+/);
      return ' url_token ' + hostParts.join(' ');
    })
    .replace(/[^a-z0-9_]+/g, ' ')
    .trim();

  const unigrams = cleaned
    .split(/\s+/)
    .filter((token) => token.length >= 2 && !STOPWORDS.has(token));

  const bigrams: string[] = [];
  for (let i = 0; i < unigrams.length - 1; i++) {
    bigrams.push(`${unigrams[i]}_${unigrams[i + 1]}`);
  }

  return [...unigrams, ...bigrams];
}

interface TrainedNaiveBayesModel {
  vocab: Set<string>;
  threatCounts: Map<string, number>;
  safeCounts: Map<string, number>;
  totalThreatTokens: number;
  totalSafeTokens: number;
  threatPrior: number;
  safePrior: number;
}

function trainNaiveBayes(docs: TrainingDocument[]): TrainedNaiveBayesModel {
  const vocab = new Set<string>();
  const threatCounts = new Map<string, number>();
  const safeCounts = new Map<string, number>();
  let totalThreatTokens = 0;
  let totalSafeTokens = 0;
  let threatDocs = 0;
  let safeDocs = 0;

  for (const doc of docs) {
    const tokens = tokenize(doc.text);
    if (doc.label === 'threat') {
      threatDocs++;
      for (const token of tokens) {
        vocab.add(token);
        threatCounts.set(token, (threatCounts.get(token) ?? 0) + 1);
        totalThreatTokens++;
      }
    } else {
      safeDocs++;
      for (const token of tokens) {
        vocab.add(token);
        safeCounts.set(token, (safeCounts.get(token) ?? 0) + 1);
        totalSafeTokens++;
      }
    }
  }

  const totalDocs = threatDocs + safeDocs || 1;
  return {
    vocab,
    threatCounts,
    safeCounts,
    totalThreatTokens,
    totalSafeTokens,
    threatPrior: Math.log(threatDocs / totalDocs),
    safePrior: Math.log(safeDocs / totalDocs),
  };
}

function predictWithModel(
  model: TrainedNaiveBayesModel,
  text: string
): { threatProbability: number; topThreatTokens: string[] } {
  const tokens = tokenize(text);
  const vocabSize = Math.max(model.vocab.size, 1);

  let logThreat = model.threatPrior;
  let logSafe = model.safePrior;

  const tokenContributions: { token: string; logRatio: number }[] = [];

  for (const token of tokens) {
    const tCount = model.threatCounts.get(token) ?? 0;
    const sCount = model.safeCounts.get(token) ?? 0;

    const pThreat = (tCount + 1) / (model.totalThreatTokens + vocabSize);
    const pSafe = (sCount + 1) / (model.totalSafeTokens + vocabSize);

    logThreat += Math.log(pThreat);
    logSafe += Math.log(pSafe);

    const ratio = Math.log(pThreat / pSafe);
    if (ratio > 0.35 && !token.includes('_')) {
      tokenContributions.push({ token, logRatio: ratio });
    }
  }

  // Log-sum-exp normalization
  const maxLog = Math.max(logThreat, logSafe);
  const expThreat = Math.exp(logThreat - maxLog);
  const expSafe = Math.exp(logSafe - maxLog);
  const threatProbability = expThreat / (expThreat + expSafe);

  const uniqueTop = Array.from(
    new Set(
      tokenContributions
        .sort((a, b) => b.logRatio - a.logRatio)
        .map((t) => t.token)
    )
  ).slice(0, 6);

  return { threatProbability, topThreatTokens: uniqueTop };
}

function seededShuffle<T>(items: T[], seed: number): T[] {
  const copy = [...items];
  let s = seed;
  for (let i = copy.length - 1; i > 0; i--) {
    s = (s * 1664525 + 1013904223) % 4294967296;
    const j = s % (i + 1);
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function evaluateBaselineModel(): {
  productionModel: TrainedNaiveBayesModel;
  evaluation: ModelEvaluationInfo;
} {
  const threatDocs = seededShuffle(
    LABELED_DATASET.filter((d) => d.label === 'threat'),
    42
  );
  const safeDocs = seededShuffle(
    LABELED_DATASET.filter((d) => d.label === 'safe'),
    42
  );

  const threatSplit = Math.floor(threatDocs.length * 0.8);
  const safeSplit = Math.floor(safeDocs.length * 0.8);

  const trainSet = [...threatDocs.slice(0, threatSplit), ...safeDocs.slice(0, safeSplit)];
  const testSet = [...threatDocs.slice(threatSplit), ...safeDocs.slice(safeSplit)];

  const evalModel = trainNaiveBayes(trainSet);

  let tp = 0;
  let fp = 0;
  let fn = 0;
  let tn = 0;

  for (const doc of testSet) {
    const { threatProbability } = predictWithModel(evalModel, doc.text);
    const predicted: BinaryLabel = threatProbability >= 0.5 ? 'threat' : 'safe';
    if (predicted === 'threat' && doc.label === 'threat') tp++;
    else if (predicted === 'threat' && doc.label === 'safe') fp++;
    else if (predicted === 'safe' && doc.label === 'threat') fn++;
    else tn++;
  }

  const total = testSet.length || 1;
  const accuracy = (tp + tn) / total;
  const precision = tp + fp > 0 ? tp / (tp + fp) : 0;
  const recall = tp + fn > 0 ? tp / (tp + fn) : 0;
  const f1Score = precision + recall > 0 ? (2 * precision * recall) / (precision + recall) : 0;

  // Train final runtime model on full labeled dataset
  const productionModel = trainNaiveBayes(LABELED_DATASET);

  return {
    productionModel,
    evaluation: {
      algorithm: 'Multinomial Naive Bayes (Unigram + Bigram, Laplace Smoothing)',
      datasetSize: LABELED_DATASET.length,
      trainSize: trainSet.length,
      testSize: testSet.length,
      accuracy: Number((accuracy * 100).toFixed(1)),
      precision: Number((precision * 100).toFixed(1)),
      recall: Number((recall * 100).toFixed(1)),
      f1Score: Number((f1Score * 100).toFixed(1)),
      limitations: [
        'Trained on a compact curated benchmark dataset; novel scam phrasing requires contextual AI or lexical rules.',
        'Does not query live domain WHOIS/DNS registries or execute external URLs.',
        'Risk scores represent estimated likelihood indicators, never 100% detection guarantees.',
      ],
    },
  };
}

const { productionModel, evaluation } = evaluateBaselineModel();

export function classifyWithNaiveBayes(text: string): {
  threatProbability: number;
  topThreatTokens: string[];
  evaluation: ModelEvaluationInfo;
} {
  const result = predictWithModel(productionModel, text);
  return {
    ...result,
    evaluation,
  };
}

export function getModelEvaluation(): ModelEvaluationInfo {
  return evaluation;
}
