import crypto from 'node:crypto';
import {
  Classification,
  ReasoningItem,
  RiskLevel,
  ScanMode,
  ScanResult,
  SuspiciousPattern,
  UnderstandTheThreat,
  UrlDiagnostics,
  UrlStructuralCheck,
} from '../src/types/scamshield';
import { classifyWithNaiveBayes } from './mlClassifier';

export interface ScanInput {
  mode: ScanMode;
  content: string;
  subject?: string;
  sender?: string;
}

const KNOWN_BRANDS: { name: string; domain: string }[] = [
  { name: 'PayPal', domain: 'paypal.com' },
  { name: 'Apple', domain: 'apple.com' },
  { name: 'Microsoft', domain: 'microsoft.com' },
  { name: 'Google', domain: 'google.com' },
  { name: 'Amazon', domain: 'amazon.com' },
  { name: 'Chase', domain: 'chase.com' },
  { name: 'Bank of America', domain: 'bankofamerica.com' },
  { name: 'Wells Fargo', domain: 'wellsfargo.com' },
  { name: 'Netflix', domain: 'netflix.com' },
  { name: 'DHL', domain: 'dhl.com' },
  { name: 'FedEx', domain: 'fedex.com' },
  { name: 'USPS', domain: 'usps.com' },
  { name: 'Coinbase', domain: 'coinbase.com' },
  { name: 'Binance', domain: 'binance.com' },
  { name: 'Instagram', domain: 'instagram.com' },
  { name: 'WhatsApp', domain: 'whatsapp.com' },
  { name: 'DocuSign', domain: 'docusign.com' },
  { name: 'Dropbox', domain: 'dropbox.com' },
  { name: 'Adobe', domain: 'adobe.com' },
  { name: 'LinkedIn', domain: 'linkedin.com' },
  { name: 'Walmart', domain: 'walmart.com' },
  { name: 'Venmo', domain: 'venmo.com' },
];

const HIGH_RISK_TLDS = new Set([
  'tk', 'ml', 'ga', 'cf', 'gq', 'xyz', 'top', 'click', 'loan', 'buzz', 'work',
  'support', 'cam', 'icu', 'monster', 'rest', 'shop', 'online', 'site',
]);

const URL_SHORTENERS = new Set([
  'bit.ly', 'tinyurl.com', 't.co', 'rb.gy', 'ow.ly', 'is.gd', 'cutt.ly',
  'buff.ly', 'tiny.cc', 'shorturl.at', 'soo.gd',
]);

function levenshtein(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  const dp: number[][] = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
    }
  }
  return dp[m][n];
}

function normalizeLookalikes(label: string): string {
  return label
    .toLowerCase()
    .replace(/0/g, 'o')
    .replace(/1/g, 'l')
    .replace(/3/g, 'e')
    .replace(/4/g, 'a')
    .replace(/5/g, 's')
    .replace(/rn/g, 'm')
    .replace(/vv/g, 'w');
}

function shannonEntropy(str: string): number {
  if (!str) return 0;
  const freq = new Map<string, number>();
  for (const ch of str) {
    freq.set(ch, (freq.get(ch) ?? 0) + 1);
  }
  let entropy = 0;
  for (const count of freq.values()) {
    const p = count / str.length;
    entropy -= p * Math.log2(p);
  }
  return Number(entropy.toFixed(2));
}

function detectBrandTyposquat(hostname: string): string | null {
  const cleanHost = hostname.toLowerCase().replace(/^www\./, '');
  const parts = cleanHost.split('.');
  const secondLevel = parts.length >= 2 ? parts[parts.length - 2] : cleanHost;
  const normalizedSld = normalizeLookalikes(secondLevel);

  for (const brand of KNOWN_BRANDS) {
    const brandCore = brand.domain.split('.')[0];
    if (cleanHost === brand.domain || cleanHost.endsWith('.' + brand.domain)) {
      return null; // Official domain match
    }
    // Brand name embedded inside compound domain (e.g. paypal-security-verify.xyz)
    if (
      cleanHost.includes(brandCore) ||
      normalizeLookalikes(cleanHost).includes(brandCore)
    ) {
      return brand.name;
    }
    // Close edit distance on second-level domain
    if (
      brandCore.length >= 5 &&
      (levenshtein(secondLevel, brandCore) <= 2 || levenshtein(normalizedSld, brandCore) <= 1)
    ) {
      return brand.name;
    }
  }
  return null;
}

export function analyzeUrlStructure(rawUrl: string): {
  diagnostics: UrlDiagnostics;
  scoreDelta: number;
  patterns: SuspiciousPattern[];
  reasons: ReasoningItem[];
} {
  const trimmed = rawUrl.trim();
  const hadExplicitScheme = /^[a-zA-Z][a-zA-Z\d+\-.]*:/.test(trimmed);
  const candidate = hadExplicitScheme ? trimmed : `https://${trimmed}`;

  const patterns: SuspiciousPattern[] = [];
  const reasons: ReasoningItem[] = [];
  const checks: UrlStructuralCheck[] = [];
  let scoreDelta = 0;

  let parsed: URL;
  try {
    parsed = new URL(candidate);
  } catch {
    return {
      diagnostics: {
        normalizedUrl: trimmed,
        protocol: 'invalid',
        hostname: 'unparseable',
        subdomainCount: 0,
        tld: '',
        hasHttps: false,
        hasPunycode: false,
        hasIpAddress: false,
        hasAtSymbol: trimmed.includes('@'),
        isShortener: false,
        brandImpersonation: null,
        entropy: shannonEntropy(trimmed),
        structuralChecks: [
          {
            label: 'URL Syntax Validation',
            status: 'fail',
            detail: 'The submitted string is not a well-formed web URL.',
          },
        ],
      },
      scoreDelta: 45,
      patterns: [
        {
          phrase: trimmed.slice(0, 80),
          category: 'Malformed URL',
          explanation: 'Input does not conform to standard URL syntax, which can indicate obfuscation.',
          severity: 'medium',
          source: 'lexical',
        },
      ],
      reasons: [
        {
          title: 'Malformed URL structure',
          detail: 'The link could not be parsed cleanly into a standard protocol and domain.',
          certainty: 'detected-evidence',
        },
      ],
    };
  }

  const protocol = parsed.protocol.toLowerCase();
  const hostname = parsed.hostname.toLowerCase();
  const labels = hostname.split('.').filter(Boolean);
  const tld = labels.length > 1 ? labels[labels.length - 1] : '';
  const subdomainCount = Math.max(0, labels.length - 2);
  const hasHttps = protocol === 'https:';
  const hasPunycode = labels.some((l) => l.startsWith('xn--')) || /[^\x20-\x7E]/.test(trimmed);
  const hasIpAddress =
    /^(\d{1,3}\.){3}\d{1,3}$/.test(hostname) ||
    /^\[.*\]$/.test(hostname) ||
    /^0x[0-9a-f]+$/i.test(labels[0] ?? '');
  const hasAtSymbol = parsed.username !== '' || parsed.password !== '' || trimmed.includes('@');
  const isShortener = URL_SHORTENERS.has(hostname.replace(/^www\./, ''));
  const brandImpersonation = detectBrandTyposquat(hostname);
  const entropy = shannonEntropy(hostname + parsed.pathname);

  // 1. Protocol check (never treat HTTPS alone as proof of safety)
  if (protocol === 'javascript:' || protocol === 'data:') {
    scoreDelta += 65;
    checks.push({
      label: 'Protocol Scheme',
      status: 'fail',
      detail: `Dangerous executable scheme (${protocol}) detected.`,
    });
    patterns.push({
      phrase: protocol,
      category: 'Executable URI Scheme',
      explanation: 'Executable schemes like javascript: or data: can run scripts instead of opening a safe page.',
      severity: 'high',
      source: 'lexical',
    });
    reasons.push({
      title: 'Executable URI scheme detected',
      detail: `The link uses "${protocol}", which is never used for legitimate login or informational websites.`,
      certainty: 'detected-evidence',
    });
  } else if (!hasHttps && hadExplicitScheme) {
    scoreDelta += 18;
    checks.push({
      label: 'Transport Encryption (HTTPS)',
      status: 'warn',
      detail: 'Uses unencrypted HTTP. Traffic and entered credentials can be intercepted.',
    });
    patterns.push({
      phrase: 'http://',
      category: 'Unencrypted Connection',
      explanation: 'No HTTPS encryption; legitimate banking or login pages always require HTTPS.',
      severity: 'medium',
      source: 'lexical',
    });
    reasons.push({
      title: 'Unencrypted HTTP protocol',
      detail: 'The link specifies http:// rather than https://, leaving data unencrypted in transit.',
      certainty: 'detected-evidence',
    });
  } else {
    checks.push({
      label: 'Transport Encryption (HTTPS)',
      status: 'pass',
      detail: 'Uses HTTPS, though attackers also obtain free TLS certificates—HTTPS alone does not prove safety.',
    });
  }

  // 2. IP Address Host
  if (hasIpAddress) {
    scoreDelta += 34;
    checks.push({
      label: 'Domain vs. Raw IP Host',
      status: 'fail',
      detail: `Uses a raw IP address (${hostname}) instead of a registered domain name.`,
    });
    patterns.push({
      phrase: hostname,
      category: 'Raw IP Hostname',
      explanation: 'Legitimate consumer services rarely send users directly to raw numeric IP addresses.',
      severity: 'high',
      source: 'lexical',
    });
    reasons.push({
      title: 'Raw IP address instead of domain name',
      detail: `Hosting a login or account portal directly on IP "${hostname}" avoids domain reputation checks.`,
      certainty: 'detected-evidence',
    });
  } else {
    checks.push({
      label: 'Domain vs. Raw IP Host',
      status: 'pass',
      detail: 'Uses a standard domain name rather than a raw IP literal.',
    });
  }

  // 3. Brand Impersonation / Typosquatting
  if (brandImpersonation) {
    scoreDelta += 40;
    checks.push({
      label: 'Brand Lookalike Check',
      status: 'fail',
      detail: `Resembles "${brandImpersonation}" on an unofficial domain (${hostname}).`,
    });
    patterns.push({
      phrase: hostname,
      category: 'Brand Lookalike Domain',
      explanation: `Appears to mimic ${brandImpersonation} without matching its official domain.`,
      severity: 'high',
      source: 'lexical',
    });
    reasons.push({
      title: `Possible ${brandImpersonation} domain impersonation`,
      detail: `The hostname "${hostname}" closely resembles or embeds "${brandImpersonation}", which is a common phishing technique.`,
      certainty: 'detected-evidence',
    });
  } else {
    checks.push({
      label: 'Brand Lookalike Check',
      status: 'pass',
      detail: 'No obvious typosquatting match against major monitored brands.',
    });
  }

  // 4. @ Credential Masking
  if (hasAtSymbol) {
    scoreDelta += 35;
    checks.push({
      label: 'Authority Obfuscation (@)',
      status: 'fail',
      detail: 'Contains an "@" symbol in the URL authority, which can disguise the real destination domain.',
    });
    patterns.push({
      phrase: '@',
      category: 'URL Authority Masking',
      explanation: 'Everything before "@" may look like a trusted site while the browser actually visits the domain after "@".',
      severity: 'high',
      source: 'lexical',
    });
    reasons.push({
      title: 'URL contains "@" obfuscation',
      detail: 'The "@" character in a URL can trick readers into trusting the prefix while directing to another host.',
      certainty: 'detected-evidence',
    });
  }

  // 5. Punycode / Homograph
  if (hasPunycode) {
    scoreDelta += 30;
    checks.push({
      label: 'Internationalized / Punycode Check',
      status: 'fail',
      detail: 'Contains punycode (xn--) or non-ASCII characters that may visually spoof familiar letters.',
    });
    patterns.push({
      phrase: hostname,
      category: 'IDN Homograph Risk',
      explanation: 'Punycode or lookalike Unicode glyphs can mimic trusted brand letters.',
      severity: 'high',
      source: 'lexical',
    });
    reasons.push({
      title: 'Lookalike character encoding detected',
      detail: 'The URL uses punycode or non-standard characters, which can be used in homograph spoofing.',
      certainty: 'detected-evidence',
    });
  }

  // 6. Excessive Subdomains
  if (subdomainCount >= 3) {
    scoreDelta += 20;
    checks.push({
      label: 'Subdomain Depth',
      status: 'warn',
      detail: `${subdomainCount} subdomain levels detected—attackers stack trusted words ahead of their real domain.`,
    });
    reasons.push({
      title: 'Deeply nested subdomains',
      detail: `The host "${hostname}" stacks ${subdomainCount} subdomain segments, which can obscure the actual root domain.`,
      certainty: 'uncertain-indication',
    });
  } else {
    checks.push({
      label: 'Subdomain Depth',
      status: 'pass',
      detail: `${subdomainCount} subdomain level(s) — normal domain depth.`,
    });
  }

  // 7. High-risk TLD
  if (HIGH_RISK_TLDS.has(tld)) {
    scoreDelta += 18;
    checks.push({
      label: 'Top-Level Domain (TLD)',
      status: 'warn',
      detail: `Uses ".${tld}", a TLD frequently seen in low-cost disposable phishing campaigns.`,
    });
    patterns.push({
      phrase: `.${tld}`,
      category: 'Elevated-Risk TLD',
      explanation: `The ".${tld}" domain extension is disproportionately used in short-lived spam/phishing campaigns, though legitimate sites can also use it.`,
      severity: 'medium',
      source: 'lexical',
    });
    reasons.push({
      title: `Elevated-risk top-level domain (.${tld})`,
      detail: `While legitimate businesses occasionally use .${tld}, it is frequently abused for disposable phishing domains.`,
      certainty: 'uncertain-indication',
    });
  } else if (tld) {
    checks.push({
      label: 'Top-Level Domain (TLD)',
      status: 'pass',
      detail: `Standard ".${tld}" top-level domain.`,
    });
  }

  // 8. URL Shortener
  if (isShortener) {
    scoreDelta += 18;
    checks.push({
      label: 'URL Shortener Check',
      status: 'warn',
      detail: `Uses link shortener (${hostname}), hiding the final destination until clicked.`,
    });
    patterns.push({
      phrase: hostname,
      category: 'Obfuscated Destination',
      explanation: 'Shortened links mask where you will actually land. Do not trust blind shortlinks from unknown senders.',
      severity: 'medium',
      source: 'lexical',
    });
    reasons.push({
      title: 'Destination hidden behind URL shortener',
      detail: `Because "${hostname}" redirects elsewhere, the true destination domain cannot be verified statically.`,
      certainty: 'uncertain-indication',
    });
  }

  // 9. Suspicious path/query lure terms & unusual port
  if (parsed.port && parsed.port !== '443' && parsed.port !== '80') {
    scoreDelta += 16;
    checks.push({
      label: 'Network Port',
      status: 'warn',
      detail: `Non-standard port :${parsed.port} specified in the URL.`,
    });
    patterns.push({
      phrase: `:${parsed.port}`,
      category: 'Non-Standard Port',
      explanation: 'Consumer login pages virtually never operate on non-standard ports.',
      severity: 'medium',
      source: 'lexical',
    });
  }

  const pathAndQuery = (parsed.pathname + parsed.search).toLowerCase();
  const lureTerms = ['login', 'verify', 'signin', 'account', 'secure', 'update', 'password', 'wallet', 'kyc', 'billing'];
  const matchedLureTerms = lureTerms.filter((term) => pathAndQuery.includes(term));
  if (matchedLureTerms.length >= 2 && (brandImpersonation || HIGH_RISK_TLDS.has(tld) || hasIpAddress || !hasHttps)) {
    scoreDelta += 14;
    patterns.push({
      phrase: parsed.pathname.slice(0, 50),
      category: 'Credential Path Pattern',
      explanation: `Path combines sensitive account keywords (${matchedLureTerms.slice(0, 3).join(', ')}) on an unverified host.`,
      severity: 'medium',
      source: 'lexical',
    });
  }

  return {
    diagnostics: {
      normalizedUrl: parsed.href,
      protocol: protocol.replace(':', ''),
      hostname,
      subdomainCount,
      tld,
      hasHttps,
      hasPunycode,
      hasIpAddress,
      hasAtSymbol,
      isShortener,
      brandImpersonation,
      entropy,
      structuralChecks: checks,
    },
    scoreDelta,
    patterns,
    reasons,
  };
}

interface RuleDefinition {
  regex: RegExp;
  category: string;
  weight: number;
  severity: 'low' | 'medium' | 'high';
  explanation: string;
  reasonTitle: string;
  certainty: 'detected-evidence' | 'uncertain-indication';
}

const TEXT_RULES: RuleDefinition[] = [
  {
    regex: /\b(urgent|immediately|within \d+ hours|act now|final notice|expires today|asap|right away|permanently locked|account suspended)\b/gi,
    category: 'Artificial Urgency',
    weight: 18,
    severity: 'high',
    explanation: 'Creates time pressure to make you act before checking with the official organization.',
    reasonTitle: 'High-pressure urgency language',
    certainty: 'detected-evidence',
  },
  {
    regex: /\b(verify your (identity|account|password|card)|confirm (your )?(ssn|social security|pin|otp|one-time|passcode|seed phrase|billing)|enter your password|update payment)\b/gi,
    category: 'Credential / Sensitive Data Request',
    weight: 28,
    severity: 'high',
    explanation: 'Requests sensitive credentials, passcodes, or payment data that legitimate teams never ask for via unsolicited links.',
    reasonTitle: 'Requests sensitive credentials or verification data',
    certainty: 'detected-evidence',
  },
  {
    regex: /\b(gift cards?|apple gift|google play card|wire transfer|bitcoin|crypto wallet|redelivery fee|customs fee|processing fee|send deposit)\b/gi,
    category: 'Irreversible Payment Lure',
    weight: 26,
    severity: 'high',
    explanation: 'Asks for gift cards, crypto, wire transfers, or unexpected small fees—hallmarks of fraud.',
    reasonTitle: 'Unusual payment or fee demand',
    certainty: 'detected-evidence',
  },
  {
    regex: /\b(congratulations|randomly selected|claim your (prize|reward)|unclaimed (lottery|grant)|guaranteed return|double your|earn \$?\d+,?\d*\s*weekly)\b/gi,
    category: 'Too-Good-To-Be-True Offer',
    weight: 24,
    severity: 'high',
    explanation: 'Promises unexpected prizes, easy money, or guaranteed returns to entice clicks.',
    reasonTitle: 'Unsolicited financial reward or prize claim',
    certainty: 'detected-evidence',
  },
  {
    regex: /\b(keep this discreet|cannot take calls|stuck in a (board )?meeting|quick confidential favor)\b/gi,
    category: 'Secrecy / Isolation Tactic',
    weight: 26,
    severity: 'high',
    explanation: 'Discourages calling or verifying with colleagues—a classic Business Email Compromise tactic.',
    reasonTitle: 'Discourages out-of-band verification',
    certainty: 'detected-evidence',
  },
  {
    regex: /\b(dear customer|dear user|valued member|account holder)\b/gi,
    category: 'Generic Salutation',
    weight: 8,
    severity: 'low',
    explanation: 'Generic greeting instead of your name can indicate mass phishing, though some automated notices also use generic greetings.',
    reasonTitle: 'Impersonal mass greeting',
    certainty: 'uncertain-indication',
  },
];

function extractUrlsFromText(text: string): string[] {
  const matches = text.match(/(?:https?:\/\/|www\.)[^\s<>"{}|\\^`[\]]+|(?:bit\.ly|tinyurl\.com|rb\.gy)\/[^\s<>"{}|\\^`[\]]+/gi);
  return matches ? Array.from(new Set(matches)).slice(0, 5) : [];
}

function analyzeSenderMismatch(sender: string, bodyAndSubject: string): {
  delta: number;
  pattern?: SuspiciousPattern;
  reason?: ReasoningItem;
} {
  const emailMatch = sender.match(/<([^>]+)>/) ?? sender.match(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/);
  const emailAddr = emailMatch?.[1]?.toLowerCase() ?? '';
  if (!emailAddr) return { delta: 0 };

  const domain = emailAddr.split('@')[1] ?? '';
  const combinedLower = (sender + ' ' + bodyAndSubject).toLowerCase();
  const freeMail = new Set(['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'aol.com', 'proton.me']);

  for (const brand of KNOWN_BRANDS) {
    const brandCore = brand.domain.split('.')[0];
    if (combinedLower.includes(brandCore) && !domain.endsWith(brand.domain)) {
      return {
        delta: 32,
        pattern: {
          phrase: emailAddr,
          category: 'Sender Domain Mismatch',
          explanation: `Claims or references ${brand.name}, yet originates from unrelated domain "@${domain}".`,
          severity: 'high',
          source: 'lexical',
        },
        reason: {
          title: `Sender address does not match ${brand.name}`,
          detail: `The message references ${brand.name}, but the sender domain is "@${domain}" rather than "@${brand.domain}".`,
          certainty: 'detected-evidence',
        },
      };
    }
  }

  if (freeMail.has(domain) && /\b(ceo|director|hr|payroll|finance|support|security)\b/i.test(sender)) {
    return {
      delta: 22,
      pattern: {
        phrase: emailAddr,
        category: 'Free Webmail Executive / Corporate Spoof',
        explanation: `Uses a public webmail address (@${domain}) while claiming an official corporate role.`,
        severity: 'medium',
        source: 'lexical',
      },
      reason: {
        title: 'Official role claimed from free webmail account',
        detail: `The sender display implies an executive or corporate role, but uses "@${domain}".`,
        certainty: 'detected-evidence',
      },
    };
  }

  return { delta: 0 };
}

export interface BaselineAnalysis {
  riskScore: number;
  classification: Classification;
  riskLevel: RiskLevel;
  suspiciousPatterns: SuspiciousPattern[];
  detailedReasoning: ReasoningItem[];
  recommendedActions: string[];
  understandTheThreat: UnderstandTheThreat;
  urlDiagnostics?: UrlDiagnostics;
  mlProbability: number;
  matchedFeatures: string[];
  modelAccuracy: number;
  modelF1: number;
  datasetSize: number;
  summary: string;
  confidenceNote: string;
}

export function runBaselineAnalysis(input: ScanInput): BaselineAnalysis {
  const combinedText = [input.subject ?? '', input.sender ?? '', input.content]
    .filter(Boolean)
    .join('\n');

  const nb = classifyWithNaiveBayes(combinedText);
  const patterns: SuspiciousPattern[] = [];
  const reasons: ReasoningItem[] = [];
  let heuristicScore = 0;

  let urlDiagnostics: UrlDiagnostics | undefined;

  if (input.mode === 'url') {
    const urlRes = analyzeUrlStructure(input.content);
    urlDiagnostics = urlRes.diagnostics;
    heuristicScore += urlRes.scoreDelta;
    patterns.push(...urlRes.patterns);
    reasons.push(...urlRes.reasons);
  } else {
    // Analyze embedded URLs inside SMS / Email
    const embeddedUrls = extractUrlsFromText(input.content);
    for (const urlStr of embeddedUrls) {
      const urlRes = analyzeUrlStructure(urlStr);
      if (urlRes.scoreDelta >= 15) {
        heuristicScore += Math.min(urlRes.scoreDelta, 42);
        patterns.push(...urlRes.patterns);
        reasons.push(...urlRes.reasons);
      }
      if (!urlDiagnostics) {
        urlDiagnostics = urlRes.diagnostics;
      }
    }
  }

  if (input.mode === 'email' && input.sender) {
    const senderCheck = analyzeSenderMismatch(input.sender, `${input.subject ?? ''} ${input.content}`);
    heuristicScore += senderCheck.delta;
    if (senderCheck.pattern) patterns.push(senderCheck.pattern);
    if (senderCheck.reason) reasons.push(senderCheck.reason);
  }

  // Apply text lexical rules
  for (const rule of TEXT_RULES) {
    const matches = combinedText.match(rule.regex);
    if (matches && matches.length > 0) {
      heuristicScore += rule.weight;
      const uniqueMatchedPhrases = Array.from(new Set(matches)).slice(0, 2);
      for (const phrase of uniqueMatchedPhrases) {
        patterns.push({
          phrase,
          category: rule.category,
          explanation: rule.explanation,
          severity: rule.severity,
          source: 'lexical',
        });
      }
      reasons.push({
        title: rule.reasonTitle,
        detail: `${rule.explanation} Matched indicator: "${uniqueMatchedPhrases[0]}".`,
        certainty: rule.certainty,
      });
    }
  }

  // Blend ML Naive Bayes probability with lexical/URL heuristics
  // For URL-only mode, lexical structure carries primary weight since Naive Bayes is text-oriented
  const mlContribution =
    input.mode === 'url'
      ? Math.round(nb.threatProbability * 22)
      : Math.round(nb.threatProbability * 36);

  // Dampen ML-only spikes when zero concrete lexical/URL evidence was triggered
  const rawScore =
    patterns.length === 0
      ? Math.min(34, Math.round(nb.threatProbability * 32))
      : Math.min(98, heuristicScore + mlContribution);

  const riskScore = Math.max(4, Math.min(98, rawScore));

  // Deduplicate patterns by phrase (case-insensitive)
  const seenPhrases = new Set<string>();
  const dedupedPatterns = patterns.filter((p) => {
    const key = p.phrase.toLowerCase();
    if (seenPhrases.has(key)) return false;
    seenPhrases.add(key);
    return true;
  });

  // Determine classification & risk level
  const hasPhishingSignal = dedupedPatterns.some((p) =>
    [
      'Brand Lookalike Domain',
      'Sender Domain Mismatch',
      'Credential / Sensitive Data Request',
      'Raw IP Hostname',
      'Executable URI Scheme',
      'Secrecy / Isolation Tactic',
      'Free Webmail Executive / Corporate Spoof',
    ].includes(p.category)
  );
  const hasSpamSignal = dedupedPatterns.some((p) =>
    ['Too-Good-To-Be-True Offer'].includes(p.category)
  );

  let classification: Classification;
  let riskLevel: RiskLevel;

  if (riskScore >= 65) {
    riskLevel = 'High';
    classification = hasSpamSignal && !hasPhishingSignal ? 'Spam' : 'Potential Phishing';
  } else if (riskScore >= 36) {
    riskLevel = 'Medium';
    classification = hasSpamSignal && !hasPhishingSignal ? 'Spam' : 'Suspicious';
  } else {
    riskLevel = 'Low';
    classification = 'Likely Safe';
  }

  // Ensure honest reasoning when few or no suspicious indicators are found
  if (reasons.length === 0) {
    reasons.push({
      title: 'No overt phishing or urgency triggers detected',
      detail:
        'Static lexical checks did not identify credential harvesting, spoofed brand domains, or urgent payment demands in the submitted text.',
      certainty: 'detected-evidence',
    });
    if (nb.threatProbability >= 0.45) {
      reasons.push({
        title: 'Mild statistical similarity to flagged phrasing',
        detail:
          'The Naive Bayes text model noticed minor keyword overlap with promotional or alert wording, though no concrete scam pattern was confirmed.',
        certainty: 'uncertain-indication',
      });
    }
  }

  const summary =
    classification === 'Likely Safe'
      ? 'No strong scam or phishing indicators were detected in this submission, though you should always confirm unexpected requests through official channels.'
      : classification === 'Spam'
      ? 'This submission shows promotional or financial lure indicators commonly associated with unsolicited spam campaigns.'
      : classification === 'Potential Phishing'
      ? 'Multiple high-confidence warning signs suggest an attempt to impersonate a trusted organization or harvest sensitive information.'
      : 'Several ambiguous or elevated-risk indicators were found; treat this communication cautiously until verified independently.';

  const confidenceNote =
    dedupedPatterns.some((p) => p.severity === 'high')
      ? 'High-confidence evidence was observed directly in the submitted text or URL structure. Uncertain contextual cues are separated below.'
      : 'Assessment is based on structural and lexical patterns without external live domain lookups. Always verify unexpected requests directly.';

  const recommendedActions = buildRecommendedActions(classification, input.mode);
  const understandTheThreat = buildEducationalProfile(classification, input.mode, dedupedPatterns);

  return {
    riskScore,
    classification,
    riskLevel,
    suspiciousPatterns: dedupedPatterns,
    detailedReasoning: reasons,
    recommendedActions,
    understandTheThreat,
    urlDiagnostics,
    mlProbability: Number((nb.threatProbability * 100).toFixed(1)),
    matchedFeatures: nb.topThreatTokens,
    modelAccuracy: nb.evaluation.accuracy,
    modelF1: nb.evaluation.f1Score,
    datasetSize: nb.evaluation.datasetSize,
    summary,
    confidenceNote,
  };
}

function buildRecommendedActions(classification: Classification, mode: ScanMode): string[] {
  if (classification === 'Likely Safe') {
    return [
      'No urgent threat indicators were found, but verify unexpected requests via an independent official app or website.',
      mode === 'url'
        ? 'Confirm the domain spelling in your browser address bar before entering any account credentials.'
        : 'Avoid sharing one-time passcodes (OTPs) even when a message appears routine.',
    ];
  }

  if (classification === 'Spam') {
    return [
      'Do not click promotional links, reply to the sender, or pay small "processing" fees to claim rewards.',
      'Mark the message as spam/junk in your messaging app or email client and block the sender.',
      'If an offer claims to be from a known store, visit their official app or website directly to verify.',
    ];
  }

  const base = [
    'Do not click any links, download attachments, or reply with personal or financial information.',
    'Verify the claim independently by opening your official bank/service app or calling the number on the back of your card.',
  ];
  if (mode === 'sms') {
    base.push('Forward suspicious SMS messages to 7726 (SPAM) in supported regions and block the number.');
  } else if (mode === 'email') {
    base.push('Report the email as phishing inside your email client and warn colleagues if it impersonates leadership.');
  } else {
    base.push('If you already visited this URL and entered a password, change that password immediately and enable app-based 2FA.');
  }
  return base;
}

function buildEducationalProfile(
  classification: Classification,
  mode: ScanMode,
  patterns: SuspiciousPattern[]
): UnderstandTheThreat {
  const categories = new Set(patterns.map((p) => p.category));

  if (classification === 'Likely Safe') {
    return {
      scamType: 'No Active Threat Pattern Identified (Preventative Guidance)',
      howItWorks:
        'Legitimate communications typically provide clear context without pressuring you into immediate action on an unfamiliar link or demanding secret codes.',
      attackerGoal:
        'Even when a message appears benign, attackers sometimes start conversations casually to build rapport before introducing a link or request later.',
      infoToProtect: [
        'Account passwords and one-time passcodes (OTPs)',
        'Government ID numbers and banking details',
        'Personal home address and private recovery codes',
      ],
      futurePrevention: [
        'Navigate to financial or shopping accounts using saved bookmarks instead of message links.',
        'Check the full sender email domain—not just the display name—before trusting urgent updates.',
      ],
    };
  }

  if (categories.has('Secrecy / Isolation Tactic') || categories.has('Free Webmail Executive / Corporate Spoof')) {
    return {
      scamType: 'Business Email Compromise (BEC) / Executive Impersonation',
      howItWorks:
        'Attackers pose as a manager, CEO, or vendor using a lookalike or free email address. They claim to be unavailable by phone and request urgent gift cards, wire transfers, or payroll changes.',
      attackerGoal:
        'To exploit workplace authority and urgency so you transfer irreversible funds (like gift card PINs or wires) before checking with the real person.',
      infoToProtect: [
        'Company funds, gift card PINs, and wire authorization codes',
        'Employee payroll and banking details',
        'Corporate login credentials',
      ],
      futurePrevention: [
        'Always verify unusual payment or gift card requests via a live voice call or internal chat—never solely by replying to the email.',
        'Inspect the actual email address after the "@" symbol rather than trusting the display name.',
      ],
    };
  }

  if (categories.has('Too-Good-To-Be-True Offer')) {
    return {
      scamType: 'Prize, Giveaway, or Advance-Fee Spam Scam',
      howItWorks:
        'Messages announce unexpected winnings, unclaimed rewards, or guaranteed investment profits, then ask you to click a shortened link or pay a small shipping/processing fee.',
      attackerGoal:
        'To harvest your credit card details under the guise of a small fee, capture personal data for identity theft, or lure you into fraudulent financial transfers.',
      infoToProtect: [
        'Credit/debit card numbers and CVV codes',
        'Home address, date of birth, and phone number',
        'Cryptocurrency wallet seed phrases or approvals',
      ],
      futurePrevention: [
        'Legitimate sweepstakes and brands do not ask winners to pay fees to release a prize.',
        'Treat unsolicited "guaranteed profit" or "randomly selected" messages as high-risk spam.',
      ],
    };
  }

  if (mode === 'url' || categories.has('Brand Lookalike Domain') || categories.has('Raw IP Hostname')) {
    return {
      scamType: 'Lookalike Domain & Credential Harvesting Phishing',
      howItWorks:
        'Scammers register domains that mimic trusted brands by swapping letters (like "0" for "o" or "1" for "l") or adding words like "-verify" and "-secure". The destination page copies the real login screen to steal whatever you type.',
      attackerGoal:
        'To capture your username, password, and 2FA code in real time so they can hijack your account or drain linked funds.',
      infoToProtect: [
        'Login passwords and security questions',
        'Two-factor authentication codes and session tokens',
        'Saved payment cards and billing profiles',
      ],
      futurePrevention: [
        'Read domains right-to-left before the first "/": in "login.paypal.verify-desk.xyz", the true owner is "verify-desk.xyz", not PayPal.',
        'Use a password manager—it will refuse to autofill your password on a lookalike domain.',
      ],
    };
  }

  return {
    scamType: mode === 'sms' ? 'Smishing (SMS Phishing) & Urgency Bait' : 'Account Alert Phishing',
    howItWorks:
      'Attackers send urgent alerts about frozen bank cards, missed deliveries, or unauthorized charges to trigger panic. The message pushes you to tap an unverified link or share verification codes immediately.',
    attackerGoal:
      'To bypass your normal caution using fear or urgency, stealing login credentials, banking numbers, or one-time passcodes.',
    infoToProtect: [
      'Banking PINs, card numbers, and CVV codes',
      'One-time verification codes (OTPs)',
      'Account passwords and Social Security / national ID numbers',
    ],
    futurePrevention: [
      'Pause whenever a message imposes a countdown ("within 12 hours", "immediately").',
      'Close the message and open the official app or type the company website yourself to check your account status.',
    ],
  };
}

export function formatBaselineAsScanResult(
  id: string,
  input: ScanInput,
  baseline: BaselineAnalysis
): ScanResult {
  const previewSource = input.subject ? `${input.subject} — ${input.content}` : input.content;
  const inputPreview =
    previewSource.length > 140 ? `${previewSource.slice(0, 137)}...` : previewSource;

  return {
    id,
    mode: input.mode,
    timestamp: new Date().toISOString(),
    inputPreview,
    analyzedText: input.content,
    subject: input.subject,
    sender: input.sender,
    classification: baseline.classification,
    riskLevel: baseline.riskLevel,
    riskScore: baseline.riskScore,
    riskDisclaimer:
      'Estimated risk score derived from observed lexical, structural, and statistical indicators—not a guaranteed probability.',
    summary: baseline.summary,
    confidenceNote: baseline.confidenceNote,
    detailedReasoning: baseline.detailedReasoning,
    suspiciousPatterns: baseline.suspiciousPatterns,
    recommendedActions: baseline.recommendedActions,
    understandTheThreat: baseline.understandTheThreat,
    urlDiagnostics: baseline.urlDiagnostics,
    analysisEngine: 'baseline-ml',
    engineNotice:
      'Running on the local Naive Bayes ML & Lexical Security Engine (offline baseline mode). Live LLM contextual reasoning is inactive or unavailable.',
    mlMetrics: {
      spamProbability: baseline.mlProbability,
      matchedFeatures: baseline.matchedFeatures,
      modelAccuracy: baseline.modelAccuracy,
      modelF1: baseline.modelF1,
      datasetSize: baseline.datasetSize,
    },
  };
}

export function createScanId(): string {
  return crypto.randomUUID();
}
