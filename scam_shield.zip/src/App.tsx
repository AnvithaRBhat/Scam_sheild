import { useEffect, useState } from 'react';
import { SAMPLE_CASES } from './data/samples';
import {
  ModelEvaluationInfo,
  ScanHistoryItem,
  ScanMode,
  ScanResult,
} from './types/scamshield';
import { AwarenessSection } from './components/AwarenessSection';
import { CapabilitiesSection } from './components/CapabilitiesSection';
import { CyberBackdrop } from './components/CyberBackdrop';
import { Footer } from './components/Footer';
import { HeroSection } from './components/HeroSection';
import { HistorySection } from './components/HistorySection';
import { AppPage, Navbar } from './components/Navbar';
import { PrivacySection } from './components/PrivacySection';
import { ResultsDashboard } from './components/ResultsDashboard';
import { ScannerWorkspace } from './components/ScannerWorkspace';

const HISTORY_KEY = 'scamshield_scan_history';
const HISTORY_PREF_KEY = 'scamshield_save_history_pref';
const THEME_KEY = 'scamshield_theme';

const VALID_PAGES: AppPage[] = [
  'home',
  'scanner',
  'how-it-works',
  'threat-guide',
  'history',
  'privacy',
];

function getInitialPage(): AppPage {
  try {
    const hash = window.location.hash.replace(/^#/, '') as AppPage;
    return VALID_PAGES.includes(hash) ? hash : 'home';
  } catch {
    return 'home';
  }
}

export default function App() {
  const [activePage, setActivePage] = useState<AppPage>(getInitialPage);

  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    try {
      return localStorage.getItem(THEME_KEY) === 'light' ? 'light' : 'dark';
    } catch {
      return 'dark';
    }
  });

  const [saveHistoryEnabled, setSaveHistoryEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(HISTORY_PREF_KEY);
      return saved === null ? true : saved === 'true';
    } catch {
      return true;
    }
  });

  const [history, setHistory] = useState<ScanHistoryItem[]>(() => {
    try {
      const pref = localStorage.getItem(HISTORY_PREF_KEY);
      if (pref === 'false') return [];
      const raw = localStorage.getItem(HISTORY_KEY);
      return raw ? (JSON.parse(raw) as ScanHistoryItem[]) : [];
    } catch {
      return [];
    }
  });

  const [mode, setMode] = useState<ScanMode>('sms');
  const [content, setContent] = useState('');
  const [subject, setSubject] = useState('');
  const [sender, setSender] = useState('');

  const [isScanning, setIsScanning] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [activeResult, setActiveResult] = useState<ScanResult | null>(null);

  const [modelInfo, setModelInfo] = useState<ModelEvaluationInfo | null>(null);
  const [aiConfigured, setAiConfigured] = useState<boolean | null>(null);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    try {
      localStorage.setItem(THEME_KEY, theme);
    } catch {
      // Ignore storage failures
    }
  }, [theme]);

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace(/^#/, '') as AppPage;
      if (VALID_PAGES.includes(hash)) {
        setActivePage(hash);
      }
    };
    window.addEventListener('hashchange', handleHashChange);
    window.addEventListener('popstate', handleHashChange);
    return () => {
      window.removeEventListener('hashchange', handleHashChange);
      window.removeEventListener('popstate', handleHashChange);
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    async function loadMeta() {
      try {
        const [healthRes, modelRes] = await Promise.all([
          fetch('/api/health'),
          fetch('/api/model-info'),
        ]);
        if (!cancelled && healthRes.ok) {
          const h = (await healthRes.json()) as { aiConfigured?: boolean };
          setAiConfigured(Boolean(h.aiConfigured));
        }
        if (!cancelled && modelRes.ok) {
          const m = (await modelRes.json()) as ModelEvaluationInfo;
          setModelInfo(m);
        }
      } catch {
        // Leave indicators unset if network fails on boot
      }
    }
    loadMeta();
    return () => {
      cancelled = true;
    };
  }, []);

  const navigateTo = (page: AppPage) => {
    setActivePage(page);
    try {
      window.history.pushState(null, '', `#${page}`);
    } catch {
      // Ignore history errors in restricted frames
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const persistHistory = (items: ScanHistoryItem[]) => {
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(items.slice(0, 20)));
    } catch {
      // Ignore quota errors
    }
  };

  const handleToggleSaveHistory = () => {
    setSaveHistoryEnabled((prev) => {
      const next = !prev;
      try {
        localStorage.setItem(HISTORY_PREF_KEY, String(next));
        if (!next) {
          localStorage.removeItem(HISTORY_KEY);
          setHistory([]);
        }
      } catch {
        // Ignore storage failures
      }
      return next;
    });
  };

  const handleClearHistory = () => {
    setHistory([]);
    try {
      localStorage.removeItem(HISTORY_KEY);
    } catch {
      // Ignore storage failures
    }
  };

  const handleStartScanning = () => {
    navigateTo('scanner');
  };

  const handleTrySample = () => {
    const sample = SAMPLE_CASES[0];
    setMode(sample.mode);
    setContent(sample.content);
    setSubject(sample.subject ?? '');
    setSender(sample.sender ?? '');
    setErrorMsg(null);
    setActiveResult(null);
    navigateTo('scanner');
  };

  const handleSubmitScan = async () => {
    setIsScanning(true);
    setErrorMsg(null);

    try {
      const response = await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode,
          content,
          subject: mode === 'email' ? subject : undefined,
          sender: mode === 'email' ? sender : undefined,
        }),
      });

      const payload = (await response.json()) as ScanResult & { error?: string };
      if (!response.ok) {
        throw new Error(payload.error || 'Analysis failed. Please check your input and try again.');
      }

      setActiveResult(payload);

      if (saveHistoryEnabled) {
        const entry: ScanHistoryItem = {
          id: payload.id,
          timestamp: payload.timestamp,
          mode: payload.mode,
          preview: payload.inputPreview,
          classification: payload.classification,
          riskLevel: payload.riskLevel,
          riskScore: payload.riskScore,
          result: payload,
        };
        setHistory((prev) => {
          const updated = [entry, ...prev].slice(0, 20);
          persistHistory(updated);
          return updated;
        });
      }

      setTimeout(() => {
        const el = document.getElementById('results');
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 80);
    } catch (err) {
      setErrorMsg(
        err instanceof Error
          ? err.message
          : 'Unable to reach the analysis server. Please try again.'
      );
    } finally {
      setIsScanning(false);
    }
  };

  const handleClearScanner = () => {
    setContent('');
    setSubject('');
    setSender('');
    setErrorMsg(null);
  };

  const handleScanAgain = () => {
    setActiveResult(null);
    handleClearScanner();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectHistoryItem = (result: ScanResult) => {
    setMode(result.mode);
    setContent(result.analyzedText);
    setSubject(result.subject ?? '');
    setSender(result.sender ?? '');
    setActiveResult(result);
    navigateTo('scanner');
    setTimeout(() => {
      const el = document.getElementById('results');
      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  return (
    <div className="min-h-screen flex flex-col text-slate-900 dark:text-slate-100">
      <CyberBackdrop />
      <Navbar activePage={activePage} onNavigate={navigateTo} />

      <main className="flex-1">
        {activePage === 'home' && (
          <HeroSection
            onStartScanning={handleStartScanning}
            onTrySample={handleTrySample}
            modelInfo={modelInfo}
          />
        )}

        {activePage === 'scanner' && (
          <>
            <ScannerWorkspace
              mode={mode}
              onModeChange={(nextMode) => {
                setMode(nextMode);
                setErrorMsg(null);
              }}
              content={content}
              onContentChange={setContent}
              subject={subject}
              onSubjectChange={setSubject}
              sender={sender}
              onSenderChange={setSender}
              isScanning={isScanning}
              errorMsg={errorMsg}
              onSubmitScan={handleSubmitScan}
              onClear={handleClearScanner}
              theme={theme}
              onToggleTheme={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
              saveHistoryEnabled={saveHistoryEnabled}
              onToggleSaveHistory={handleToggleSaveHistory}
              aiConfigured={aiConfigured}
            />

            {activeResult && (
              <ResultsDashboard result={activeResult} onScanAgain={handleScanAgain} />
            )}
          </>
        )}

        {activePage === 'how-it-works' && <CapabilitiesSection modelInfo={modelInfo} />}

        {activePage === 'threat-guide' && <AwarenessSection />}

        {activePage === 'history' && (
          <HistorySection
            history={history}
            saveHistoryEnabled={saveHistoryEnabled}
            onToggleSaveHistory={handleToggleSaveHistory}
            onClearHistory={handleClearHistory}
            onSelectHistoryItem={handleSelectHistoryItem}
            onStartScanning={handleStartScanning}
          />
        )}

        {activePage === 'privacy' && (
          <PrivacySection
            saveHistoryEnabled={saveHistoryEnabled}
            onToggleSaveHistory={handleToggleSaveHistory}
            historyCount={history.length}
            onClearHistory={handleClearHistory}
            modelInfo={modelInfo}
            aiConfigured={aiConfigured}
          />
        )}
      </main>

      <Footer
        theme={theme}
        onToggleTheme={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
        onNavigate={navigateTo}
      />
    </div>
  );
}
