export type ScanMode = 'sms' | 'email' | 'url';

export type Classification =
  | 'Likely Safe'
  | 'Suspicious'
  | 'Potential Phishing'
  | 'Spam';

export type RiskLevel = 'Low' | 'Medium' | 'High';

export type PatternSeverity = 'low' | 'medium' | 'high';

export interface SuspiciousPattern {
  phrase: string;
  category: string;
  explanation: string;
  severity: PatternSeverity;
  source: 'lexical' | 'ml' | 'ai';
}

export interface ReasoningItem {
  title: string;
  detail: string;
  certainty: 'detected-evidence' | 'uncertain-indication';
}

export interface UnderstandTheThreat {
  scamType: string;
  howItWorks: string;
  attackerGoal: string;
  infoToProtect: string[];
  futurePrevention: string[];
}

export interface UrlStructuralCheck {
  label: string;
  status: 'pass' | 'warn' | 'fail';
  detail: string;
}

export interface UrlDiagnostics {
  normalizedUrl: string;
  protocol: string;
  hostname: string;
  subdomainCount: number;
  tld: string;
  hasHttps: boolean;
  hasPunycode: boolean;
  hasIpAddress: boolean;
  hasAtSymbol: boolean;
  isShortener: boolean;
  brandImpersonation: string | null;
  entropy: number;
  structuralChecks: UrlStructuralCheck[];
}

export interface MlMetrics {
  spamProbability: number;
  matchedFeatures: string[];
  modelAccuracy: number;
  modelF1: number;
  datasetSize: number;
}

export interface ScanResult {
  id: string;
  mode: ScanMode;
  timestamp: string;
  inputPreview: string;
  analyzedText: string;
  subject?: string;
  sender?: string;
  classification: Classification;
  riskLevel: RiskLevel;
  riskScore: number;
  riskDisclaimer: string;
  summary: string;
  confidenceNote: string;
  detailedReasoning: ReasoningItem[];
  suspiciousPatterns: SuspiciousPattern[];
  recommendedActions: string[];
  understandTheThreat: UnderstandTheThreat;
  urlDiagnostics?: UrlDiagnostics;
  analysisEngine: 'gemini-ai-hybrid' | 'baseline-ml';
  engineNotice: string;
  mlMetrics: MlMetrics;
}

export interface ModelEvaluationInfo {
  algorithm: string;
  datasetSize: number;
  trainSize: number;
  testSize: number;
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  limitations: string[];
}

export interface ScanHistoryItem {
  id: string;
  timestamp: string;
  mode: ScanMode;
  preview: string;
  classification: Classification;
  riskLevel: RiskLevel;
  riskScore: number;
  result: ScanResult;
}
