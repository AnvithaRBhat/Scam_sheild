import { BookOpenCheck, LockKeyhole, ShieldAlert, Target, Wrench } from 'lucide-react';
import { Classification, UnderstandTheThreat } from '../types/scamshield';

interface UnderstandThreatPanelProps {
  classification: Classification;
  data: UnderstandTheThreat;
}

export function UnderstandThreatPanel({ classification, data }: UnderstandThreatPanelProps) {
  return (
    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/70 backdrop-blur-md overflow-hidden">
      <div className="p-6 sm:p-8 border-b border-slate-200 dark:border-slate-800 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-blue-600 dark:text-cyan-400 mb-1">
            Understand the Threat · Plain-Language Defense Briefing
          </p>
          <h3 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            {data.scamType}
          </h3>
          <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
            {classification === 'Likely Safe'
              ? 'Even when a message appears benign, knowing common manipulation tactics keeps you prepared.'
              : 'Understanding the psychology and mechanics behind this alert helps you spot future variations immediately.'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
        {/* Left Visual Illustration */}
        <div className="lg:col-span-5 relative min-h-[240px] bg-slate-900 border-b lg:border-b-0 lg:border-r border-slate-200 dark:border-slate-800">
          <img
            src="/src/assets/images/threat_anatomy_visual_1794581039431.jpg"
            alt="Isometric layered security inspection gates illustrating threat anatomy"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#060A14]/90 via-[#060A14]/30 to-transparent" />
          <div className="absolute bottom-0 inset-x-0 p-5 sm:p-6">
            <p className="text-xs font-medium text-cyan-300 mb-1">
              Why Awareness Matters
            </p>
            <p className="text-sm text-slate-200 leading-relaxed">
              Most attacks succeed not by breaking encryption, but by rushing people into clicking or sharing a code before verifying.
            </p>
          </div>
        </div>

        {/* Right 5-Part Breakdown */}
        <div className="lg:col-span-7 p-6 sm:p-8 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white mb-2">
                <Wrench className="w-4 h-4 text-blue-600 dark:text-cyan-400 shrink-0" />
                <span>How the Technique Works</span>
              </div>
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {data.howItWorks}
              </p>
            </div>

            <div>
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white mb-2">
                <Target className="w-4 h-4 text-blue-600 dark:text-cyan-400 shrink-0" />
                <span>What the Sender May Want</span>
              </div>
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {data.attackerGoal}
              </p>
            </div>
          </div>

          <div className="pt-5 border-t border-slate-200 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white mb-2.5">
                <LockKeyhole className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
                <span>Information to Protect</span>
              </div>
              <ul className="space-y-2">
                {data.infoToProtect.map((item, idx) => (
                  <li
                    key={idx}
                    className="flex items-start gap-2 text-sm text-slate-700 dark:text-slate-300"
                  >
                    <ShieldAlert className="w-4 h-4 text-amber-600 dark:text-amber-400 mt-0.5 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white mb-2.5">
                <BookOpenCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <span>How to Avoid Similar Scams</span>
              </div>
              <ul className="space-y-2">
                {data.futurePrevention.map((tip, idx) => (
                  <li
                    key={idx}
                    className="flex items-start gap-2 text-sm text-slate-700 dark:text-slate-300"
                  >
                    <span className="font-mono text-xs text-emerald-600 dark:text-emerald-400 mt-1 shrink-0">
                      0{idx + 1}.
                    </span>
                    <span>{tip}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
