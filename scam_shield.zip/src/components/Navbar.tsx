import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { ScamShieldLogo } from './ScamShieldLogo';

export type AppPage =
  | 'home'
  | 'scanner'
  | 'how-it-works'
  | 'threat-guide'
  | 'history'
  | 'privacy';

interface NavbarProps {
  activePage: AppPage;
  onNavigate: (page: AppPage) => void;
}

export function Navbar({ activePage, onNavigate }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems: { label: string; page: AppPage }[] = [
    { label: 'Scanner', page: 'scanner' },
    { label: 'How It Works', page: 'how-it-works' },
    { label: 'Threat Guide', page: 'threat-guide' },
    { label: 'History', page: 'history' },
    { label: 'Privacy Model', page: 'privacy' },
  ];

  const handleSelect = (page: AppPage) => {
    setMobileOpen(false);
    onNavigate(page);
  };

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/80 dark:border-slate-800/80 bg-white/85 dark:bg-[#060A14]/85 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand wordmark + icon, single-line */}
        <button
          type="button"
          onClick={() => handleSelect('home')}
          className="flex items-center gap-2.5 whitespace-nowrap shrink-0 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500 rounded-md"
        >
          <ScamShieldLogo className="w-7 h-7 shrink-0" />
          <span className="font-display text-lg font-bold tracking-tight text-slate-900 dark:text-white">
            scam_shield
          </span>
        </button>

        {/* Zone 2: 5 concise single-line navigation links */}
        <nav
          aria-label="Primary Navigation"
          className="hidden md:flex items-center gap-4 lg:gap-6 text-xs lg:text-sm font-medium text-slate-600 dark:text-slate-300"
        >
          {navItems.map((item) => {
            const isActive = activePage === item.page;
            return (
              <button
                key={item.page}
                type="button"
                onClick={() => handleSelect(item.page)}
                aria-current={isActive ? 'page' : undefined}
                className={`whitespace-nowrap shrink-0 py-1.5 border-b-2 transition-colors duration-150 cursor-pointer ${
                  isActive
                    ? 'text-blue-600 dark:text-cyan-300 border-blue-600 dark:border-cyan-400 font-semibold'
                    : 'border-transparent hover:text-blue-600 dark:hover:text-cyan-300 hover:border-blue-600/50 dark:hover:border-cyan-400/50'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 primary CTA */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => handleSelect('scanner')}
            className="hidden sm:inline-flex items-center justify-center px-4 py-2 text-xs lg:text-sm font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 dark:bg-cyan-500 dark:hover:bg-cyan-400 text-white dark:text-slate-950 transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
          >
            Start Scanning
          </button>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            className="md:hidden inline-flex items-center justify-center w-10 h-10 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/70 transition-colors cursor-pointer"
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileOpen}
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-[#080D1A] px-4 py-4 space-y-1.5">
          <button
            type="button"
            onClick={() => handleSelect('home')}
            className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium cursor-pointer ${
              activePage === 'home'
                ? 'bg-blue-50 dark:bg-cyan-950/40 text-blue-700 dark:text-cyan-300'
                : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/70'
            }`}
          >
            Home
          </button>
          {navItems.map((item) => (
            <button
              key={item.page}
              type="button"
              onClick={() => handleSelect(item.page)}
              className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium cursor-pointer ${
                activePage === item.page
                  ? 'bg-blue-50 dark:bg-cyan-950/40 text-blue-700 dark:text-cyan-300'
                  : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/70'
              }`}
            >
              {item.label}
            </button>
          ))}
          <button
            type="button"
            onClick={() => handleSelect('scanner')}
            className="w-full mt-2 px-4 py-2.5 rounded-lg text-sm font-semibold bg-blue-600 dark:bg-cyan-500 text-white dark:text-slate-950 cursor-pointer"
          >
            Start Scanning
          </button>
        </div>
      )}
    </header>
  );
}
