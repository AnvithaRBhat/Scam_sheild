import { Cpu, EyeOff, GlobeLock, Lock, ShieldCheck, Trash2 } from 'lucide-react';
import { ModelEvaluationInfo } from '../types/scamshield';

interface PrivacySectionProps {
  saveHistoryEnabled: boolean;
  onToggleSaveHistory: () => void;
  historyCount: number;
  onClearHistory: () => void;
  modelInfo: ModelEvaluationInfo | null;
  aiConfigured: boolean | null;
}

export function PrivacySection({
  saveHistoryEnabled,
  onToggleSaveHistory,
  historyCount,
  onClearHistory,
  modelInfo,
  aiConfigured,
}: PrivacySectionProps) {
  return (
    <section className="py-10 lg:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="max-w-3xl">
          <p className="text-xs font-medium text-blue-600 dark:text-cyan-400 mb-2">
            Security &amp; Data Governance
          </p>
          <h1 className="font-display text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-slate-900 dark:text-white text-balance">
            Privacy &amp; Threat Inspection Model
          </h1>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 mt-3 leading-relaxed">
            Every message, email, or link you inspect is treated as sensitive and untrusted input. Here is exactly how scam_shield processes, isolates, and protects your data—alongside honest boundaries of what automated analysis can and cannot guarantee.
          </p>
        </div>

        {/* Core Privacy & Security Guarantees */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/85 dark:bg-slate-900/65 p-6">
            <div className="flex items-center gap-2.5 mb-3">
              <EyeOff className="w-5 h-5 text-blue-600 dark:text-cyan-400 shrink-0" />
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                Zero Server-Side Message Retention
              </h2>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              Submissions sent to the analysis endpoint are evaluated strictly in memory and returned directly to your browser. The Express server does not write message contents, subjects, or URLs to any database or log file.
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/85 dark:bg-slate-900/65 p-6">
            <div className="flex items-center gap-2.5 mb-3">
              <GlobeLock className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                Passive URL &amp; Untrusted Input Isolation
              </h2>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              scam_shield never opens, visits, renders, or executes submitted URLs or HTML payloads. All URL checks (protocol, punycode, raw IP host, subdomain stacking, and brand similarity) run purely on the static text string.
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/85 dark:bg-slate-900/65 p-6">
            <div className="flex items-center gap-2.5 mb-3">
              <Lock className="w-5 h-5 text-blue-600 dark:text-cyan-400 shrink-0" />
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                Server-Side API Key Isolation
              </h2>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              When hybrid AI contextual reasoning is active, prompts isolate user content inside explicit data delimiters and keep credentials strictly on the server. Status right now:{' '}
              <span className="font-semibold text-slate-900 dark:text-white">
                {aiConfigured === true
                  ? 'Hybrid Gemini AI + Baseline ML active'
                  : aiConfigured === false
                    ? 'Offline Baseline ML & Lexical Engine active'
                    : 'Checking server engine...'}
              </span>
              .
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/85 dark:bg-slate-900/65 p-6">
            <div className="flex items-center gap-2.5 mb-3">
              <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                Browser-Only Optional History Controls
              </h2>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
              Scan history is stored only in your browser&apos;s local storage when enabled, so you can review past scans without creating an account. You can disable storage or wipe saved scans at any moment.
            </p>
            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={onToggleSaveHistory}
                className="px-3.5 py-2 rounded-xl text-xs font-semibold border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 hover:border-blue-500 dark:hover:border-cyan-400 transition-colors cursor-pointer"
              >
                Local History: {saveHistoryEnabled ? 'Enabled (Click to Disable)' : 'Disabled (Click to Enable)'}
              </button>

              {historyCount > 0 && (
                <button
                  type="button"
                  onClick={onClearHistory}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium border border-rose-300 dark:border-rose-900/70 text-rose-700 dark:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear {historyCount} Saved Scan(s)</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Baseline Model Transparency & Limitations */}
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/85 dark:bg-slate-900/65 p-6 sm:p-8">
          <div className="flex items-center gap-2.5 mb-3">
            <Cpu className="w-5 h-5 text-blue-600 dark:text-cyan-400 shrink-0" />
            <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
              Transparent Model Evaluation &amp; Known Limitations
            </h2>
          </div>

          {modelInfo && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 my-5 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#080D1A]">
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400">Algorithm</p>
                <p className="text-xs sm:text-sm font-semibold text-slate-900 dark:text-white mt-0.5">
                  Multinomial Naive Bayes
                </p>
              </div>
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400">Held-Out Accuracy</p>
                <p className="font-mono text-base font-bold tabular-nums text-emerald-600 dark:text-emerald-400 mt-0.5">
                  {modelInfo.accuracy}%
                </p>
              </div>
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400">Precision / Recall</p>
                <p className="font-mono text-base font-bold tabular-nums text-slate-900 dark:text-white mt-0.5">
                  {modelInfo.precision}% / {modelInfo.recall}%
                </p>
              </div>
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400">F1 Score ({modelInfo.testSize} Test)</p>
                <p className="font-mono text-base font-bold tabular-nums text-blue-600 dark:text-cyan-400 mt-0.5">
                  {modelInfo.f1Score}%
                </p>
              </div>
            </div>
          )}

          <ul className="space-y-2.5 text-sm text-slate-600 dark:text-slate-300">
            {(modelInfo?.limitations ?? [
              'Automated risk scores are preliminary estimates and never guarantee 100% detection accuracy.',
              'Static URL analysis does not query live domain WHOIS age or external threat feeds.',
              'Always verify urgent banking, delivery, or account requests through official apps or known phone numbers.',
            ]).map((lim, idx) => (
              <li key={idx} className="flex items-start gap-2.5">
                <span className="font-mono text-xs text-blue-600 dark:text-cyan-400 mt-1 shrink-0">
                  0{idx + 1}.
                </span>
                <span>{lim}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
