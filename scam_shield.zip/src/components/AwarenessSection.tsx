import { useState } from 'react';
import { ChevronDown, ChevronUp, ShieldAlert } from 'lucide-react';

interface AwarenessGuide {
  id: string;
  title: string;
  summary: string;
  redFlags: string[];
  defenseHabit: string;
}

const AWARENESS_GUIDES: AwarenessGuide[] = [
  {
    id: 'smishing',
    title: '01. Smishing & Fake Delivery Texts',
    summary:
      'Text messages claiming a missed parcel, unpaid toll, or locked bank card push you to tap a short link immediately.',
    redFlags: [
      'Countdown threats ("within 12 hours" or "account closed today")',
      'Small fee requests ($1.99–$3.50) designed to harvest full card details',
      'Unfamiliar domain names containing a brand word plus "-track" or "-verify"',
    ],
    defenseHabit:
      'Close the text and check your carrier or bank using their official app or typed website.',
  },
  {
    id: 'bec',
    title: '02. Executive & Workplace Impersonation',
    summary:
      'Attackers pose as a manager or colleague on a free webmail address asking for confidential gift cards or urgent wire updates.',
    redFlags: [
      'Display name shows a coworker, but the address ends in @gmail.com or a lookalike domain',
      'Claims they are in a meeting and cannot take phone calls',
      'Asks you to keep the request discreet and bypass normal finance approvals',
    ],
    defenseHabit:
      'Call the colleague on a known phone number or internal chat before spending any money.',
  },
  {
    id: 'lookalike-urls',
    title: '03. Lookalike Domains & HTTPS Myths',
    summary:
      'Phishing pages routinely obtain valid HTTPS padlock certificates. A padlock only means traffic is encrypted—not that the site is honest.',
    redFlags: [
      'Swapped characters such as "0" for "o" or "1" for "l" (e.g., paypa1)',
      'Brand names placed as subdomains before an unrelated root domain',
      'Raw numeric IP addresses or "@" symbols inside the URL bar',
    ],
    defenseHabit:
      'Read the domain right-to-left just before the first single "/" to find who actually owns the site.',
  },
  {
    id: 'otp-harvesting',
    title: '04. One-Time Passcode (OTP) & Support Traps',
    summary:
      'Fraudsters call or message pretending to be fraud prevention and ask you to read back a 6-digit verification code.',
    redFlags: [
      'Anyone asking you to share a code that says "Do not share this with anyone"',
      'Unexpected password reset notifications followed by a live support chat link',
      'Requests to install remote screen-sharing tools to "issue a refund"',
    ],
    defenseHabit:
      'Never share one-time passcodes or approve unexpected login prompts—even if the caller sounds official.',
  },
];

export function AwarenessSection() {
  const [openId, setOpenId] = useState<string>('smishing');

  return (
    <section id="awareness" className="py-10 lg:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-10">
          <p className="text-xs font-medium text-blue-600 dark:text-cyan-400 mb-2">
            Cybersecurity Awareness Guide
          </p>
          <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white text-balance">
            Learn the core patterns scammers rely on
          </h2>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 mt-3 leading-relaxed">
            Technology helps catch red flags, while everyday habits stop social engineering before it starts. Review these four high-frequency threat playbooks.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {AWARENESS_GUIDES.map((guide) => {
            const isOpen = openId === guide.id;
            return (
              <div
                key={guide.id}
                className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/55 p-6 transition-colors"
              >
                <button
                  type="button"
                  onClick={() => setOpenId(isOpen ? '' : guide.id)}
                  aria-expanded={isOpen}
                  className="w-full flex items-start justify-between gap-4 text-left cursor-pointer"
                >
                  <div>
                    <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                      {guide.title}
                    </h3>
                    <p className="text-sm text-slate-600 dark:text-slate-300 mt-1.5 leading-relaxed">
                      {guide.summary}
                    </p>
                  </div>
                  <span className="mt-1 text-slate-500 dark:text-slate-400 shrink-0">
                    {isOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                  </span>
                </button>

                {isOpen && (
                  <div className="mt-5 pt-4 border-t border-slate-200 dark:border-slate-800 space-y-4">
                    <div>
                      <p className="text-xs font-semibold text-slate-700 dark:text-slate-200 mb-2">
                        Common Warning Signs
                      </p>
                      <ul className="space-y-1.5">
                        {guide.redFlags.map((flag, idx) => (
                          <li
                            key={idx}
                            className="flex items-start gap-2 text-xs sm:text-sm text-slate-600 dark:text-slate-300"
                          >
                            <ShieldAlert className="w-4 h-4 text-amber-600 dark:text-amber-400 mt-0.5 shrink-0" />
                            <span>{flag}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#080D1A] border border-slate-200 dark:border-slate-800">
                      <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 mb-1">
                        Practical Habit
                      </p>
                      <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                        {guide.defenseHabit}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
