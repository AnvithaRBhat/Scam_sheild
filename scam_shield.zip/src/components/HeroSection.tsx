import { ArrowRight, ShieldCheck } from 'lucide-react';
import { ModelEvaluationInfo } from '../types/scamshield';

interface HeroSectionProps {
  onStartScanning: () => void;
  onTrySample: () => void;
  modelInfo: ModelEvaluationInfo | null;
}

export function HeroSection({
  onStartScanning,
  onTrySample,
  modelInfo,
}: HeroSectionProps) {
  return (
    <section id="top" className="relative pt-12 pb-14 lg:pt-20 lg:pb-20 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
          {/* Left Column: Proposition & Primary Action */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            <p className="text-xs sm:text-sm font-medium text-blue-600 dark:text-cyan-400 mb-3 tracking-wide">
              Explainable Scam &amp; Phishing Defense · SMS, Email &amp; URL Inspection
            </p>

            <h1
              className="font-display font-bold tracking-tight text-slate-900 dark:text-white leading-[1.08] mb-5 text-balance"
              style={{ fontSize: 'clamp(2.25rem, 4vw, 3.65rem)' }}
            >
              Think Before You Click. Stay One Step Ahead.
            </h1>

            <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl mb-8">
              scam_shield inspects suspicious text messages, emails, and links before you interact with them. Instead of a vague warning label, you receive plain-English reasoning, exact highlighted red flags, and practical steps to stay protected.
            </p>

            <div className="flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={onStartScanning}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-sm sm:text-base font-semibold bg-blue-600 hover:bg-blue-700 dark:bg-cyan-500 dark:hover:bg-cyan-400 text-white dark:text-slate-950 transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer shadow-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
              >
                <span>Start Scanning</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onTrySample}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl text-sm sm:text-base font-medium border border-slate-300 dark:border-slate-700 bg-white/80 dark:bg-slate-900/60 text-slate-800 dark:text-slate-200 hover:border-blue-500 dark:hover:border-cyan-400 transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span>Try a Sample Threat</span>
              </button>
            </div>

            <p className="mt-6 text-xs sm:text-sm text-slate-500 dark:text-slate-400">
              Don&apos;t just detect scams. Understand them. Prevent them. Stay protected.
            </p>
          </div>

          {/* Right Column: Visual Focal Carrier */}
          <div className="lg:col-span-5 flex">
            <div className="relative w-full min-h-[260px] lg:min-h-[360px] rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-gradient-to-br from-slate-900 via-[#0B162C] to-[#060A14]">
              <img
                src="/src/assets/images/hero_cyber_shield_1794581039412.jpg"
                alt="scam_shield geometric defense shield refracting optical network pathways"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#060A14]/85 via-[#060A14]/20 to-transparent" />
              <div className="absolute bottom-0 inset-x-0 p-5 sm:p-6">
                <div className="flex items-center gap-2 text-xs font-medium text-cyan-300 mb-1">
                  <ShieldCheck className="w-4 h-4 shrink-0" />
                  <span>Passive Static Inspection</span>
                </div>
                <p className="text-sm text-slate-200 leading-snug">
                  Submitted messages and URLs are analyzed strictly as text—never executed or visited automatically.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Full-Width Benchmark & Illustrative Cybersecurity Context Strip */}
        <div className="mt-10 pt-8 border-t border-slate-200 dark:border-slate-800/90">
          <div className="flex flex-wrap items-baseline justify-between gap-2 mb-4">
            <h2 className="font-display text-sm font-semibold text-slate-800 dark:text-slate-200">
              Illustrative Threat Context &amp; Baseline Model Metrics
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Industry figures are illustrative educational references · Model metrics are measured on our local held-out test split
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white/70 dark:bg-slate-900/50 backdrop-blur-sm">
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">
                Illustrative Context · Social Engineering
              </p>
              <p className="font-mono text-2xl font-semibold tabular-nums text-slate-900 dark:text-white">
                3-Layer
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                Lexical rules + Naive Bayes ML + contextual AI reasoning per scan
              </p>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white/70 dark:bg-slate-900/50 backdrop-blur-sm">
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">
                Illustrative Target · Consumer Readiness
              </p>
              <p className="font-mono text-2xl font-semibold tabular-nums text-blue-600 dark:text-cyan-400">
                12+ Checks
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                Typosquatting, urgency bait, sender mismatch, punycode &amp; credential lures
              </p>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white/70 dark:bg-slate-900/50 backdrop-blur-sm">
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">
                Measured ML Split · Accuracy
              </p>
              <p className="font-mono text-2xl font-semibold tabular-nums text-emerald-600 dark:text-emerald-400">
                {modelInfo ? `${modelInfo.accuracy}%` : '—'}
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                {modelInfo
                  ? `Evaluated on ${modelInfo.testSize} held-out test samples (${modelInfo.datasetSize} total)`
                  : 'Evaluating local Naive Bayes benchmark...'}
              </p>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white/70 dark:bg-slate-900/50 backdrop-blur-sm">
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">
                Measured ML Split · F1 Score
              </p>
              <p className="font-mono text-2xl font-semibold tabular-nums text-slate-900 dark:text-white">
                {modelInfo ? `${modelInfo.f1Score}%` : '—'}
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                {modelInfo
                  ? `Precision ${modelInfo.precision}% · Recall ${modelInfo.recall}% (baseline benchmark)`
                  : 'Computing precision and recall metrics...'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
