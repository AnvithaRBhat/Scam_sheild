import { Cpu, Eye, FileSearch2, GraduationCap } from 'lucide-react';
import { ModelEvaluationInfo } from '../types/scamshield';

interface CapabilitiesSectionProps {
  modelInfo: ModelEvaluationInfo | null;
}

export function CapabilitiesSection({ modelInfo }: CapabilitiesSectionProps) {
  return (
    <section id="how-it-works" className="py-10 lg:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-10">
          <p className="text-xs font-medium text-blue-600 dark:text-cyan-400 mb-2">
            Capabilities &amp; Detection Pipeline
          </p>
          <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white text-balance">
            How scam_shield inspects suspicious communications
          </h2>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 mt-3 leading-relaxed">
            Every scan combines deterministic security engineering, an evaluated statistical text classifier, and contextual AI reasoning—so you see the exact evidence rather than a black-box verdict.
          </p>
        </div>

        {/* Asymmetric Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <div className="md:col-span-2 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/55 p-6 sm:p-7 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="font-mono text-xs font-semibold text-blue-600 dark:text-cyan-400">
                  01. Lexical &amp; Structural Security Inspection
                </span>
                <FileSearch2 className="w-5 h-5 text-blue-600 dark:text-cyan-400" />
              </div>
              <h3 className="font-display text-xl font-bold text-slate-900 dark:text-white mb-2">
                Passive inspection of URLs, senders, and urgency cues
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed max-w-xl">
                Before any AI model runs, our deterministic parser checks domain Levenshtein similarity against major brands, detects punycode homographs, flags raw IP hosts, checks sender display-name mismatches, and isolates exact manipulation phrases without ever opening links or executing content.
              </p>
            </div>
            <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500 dark:text-slate-400">
              <span>Zero external link fetching</span>
              <span aria-hidden="true">·</span>
              <span>HTTPS checked without assuming safety</span>
              <span aria-hidden="true">·</span>
              <span>Exact span highlighting</span>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/55 p-6 sm:p-7">
            <div className="flex items-center justify-between mb-4">
              <span className="font-mono text-xs font-semibold text-blue-600 dark:text-cyan-400">
                02. Baseline ML Classifier
              </span>
              <Cpu className="w-5 h-5 text-blue-600 dark:text-cyan-400" />
            </div>
            <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white mb-2">
              Evaluated Naive Bayes model
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
              Unigram and bigram probability scoring trained on labeled phishing, spam, and safe reference examples—providing a reliable offline baseline whenever external AI APIs are unreachable.
            </p>
            {modelInfo && (
              <p className="font-mono text-xs tabular-nums text-slate-700 dark:text-slate-300 pt-3 border-t border-slate-200 dark:border-slate-800">
                Test Split: {modelInfo.accuracy}% Accuracy · {modelInfo.f1Score}% F1 ({modelInfo.testSize} held-out samples)
              </p>
            )}
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/55 p-6 sm:p-7">
            <div className="flex items-center justify-between mb-4">
              <span className="font-mono text-xs font-semibold text-blue-600 dark:text-cyan-400">
                03. Explainable AI Reasoning
              </span>
              <Eye className="w-5 h-5 text-blue-600 dark:text-cyan-400" />
            </div>
            <h3 className="font-display text-lg font-bold text-slate-900 dark:text-white mb-2">
              Evidence vs. uncertainty separation
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              Every verdict separates confirmed evidence from uncertain indications. scam_shield never invents reasons or promises 100% detection certainty.
            </p>
          </div>

          <div className="md:col-span-2 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/55 p-6 sm:p-7 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="font-mono text-xs font-semibold text-blue-600 dark:text-cyan-400">
                  04. Understand the Threat
                </span>
                <GraduationCap className="w-5 h-5 text-blue-600 dark:text-cyan-400" />
              </div>
              <h3 className="font-display text-xl font-bold text-slate-900 dark:text-white mb-2">
                Turn every scan into lasting cybersecurity intuition
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed max-w-xl">
                After every scan, the Understand the Threat briefing translates technical indicators into everyday language: what scam type you are seeing, what the sender hopes to gain, which personal details to guard, and how to outsmart similar tricks next time.
              </p>
            </div>
            <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500 dark:text-slate-400">
              <span>Non-technical explanations</span>
              <span aria-hidden="true">·</span>
              <span>Concrete next actions</span>
              <span aria-hidden="true">·</span>
              <span>Downloadable scan reports</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
