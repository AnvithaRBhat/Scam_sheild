import { FormEvent, useState } from 'react';
import {
  AlertCircle,
  Eraser,
  Globe,
  History,
  Lock,
  Mail,
  MessageSquareText,
  Moon,
  SearchCheck,
  Sparkles,
  Sun,
} from 'lucide-react';
import { SAMPLE_CASES } from '../data/samples';
import { ScanMode } from '../types/scamshield';

interface ScannerWorkspaceProps {
  mode: ScanMode;
  onModeChange: (mode: ScanMode) => void;
  content: string;
  onContentChange: (value: string) => void;
  subject: string;
  onSubjectChange: (value: string) => void;
  sender: string;
  onSenderChange: (value: string) => void;
  isScanning: boolean;
  errorMsg: string | null;
  onSubmitScan: () => void;
  onClear: () => void;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  saveHistoryEnabled: boolean;
  onToggleSaveHistory: () => void;
  aiConfigured: boolean | null;
}

export function ScannerWorkspace({
  mode,
  onModeChange,
  content,
  onContentChange,
  subject,
  onSubjectChange,
  sender,
  onSenderChange,
  isScanning,
  errorMsg,
  onSubmitScan,
  onClear,
  theme,
  onToggleTheme,
  saveHistoryEnabled,
  onToggleSaveHistory,
  aiConfigured,
}: ScannerWorkspaceProps) {
  const [validationError, setValidationError] = useState<string | null>(null);

  const modeSamples = SAMPLE_CASES.filter((s) => s.mode === mode);

  const handleLoadSample = (sampleId: string) => {
    const sample = modeSamples.find((s) => s.id === sampleId);
    if (!sample) return;
    setValidationError(null);
    onContentChange(sample.content);
    onSubjectChange(sample.subject ?? '');
    onSenderChange(sample.sender ?? '');
  };

  const handleFormSubmit = (e: FormEvent) => {
    e.preventDefault();
    const trimmed = content.trim();
    if (trimmed.length < 3) {
      setValidationError(
        mode === 'url'
          ? 'Please enter a website URL (for example, https://example.com) before scanning.'
          : 'Please paste a message or email body (at least 3 characters) before scanning.'
      );
      return;
    }
    if (mode === 'url' && /\s/.test(trimmed)) {
      setValidationError(
        'URLs cannot contain spaces. Switch to the SMS or Email tab if you want to scan a full message.'
      );
      return;
    }
    setValidationError(null);
    onSubmitScan();
  };

  const displayError = validationError || errorMsg;

  return (
    <section id="scanner" className="py-10 lg:py-14">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Workspace Toolbar: Mode Tabs + Theme & Privacy Controls */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-6">
          <div
            role="tablist"
            aria-label="Scanner type"
            className="inline-flex flex-wrap items-center gap-1.5 p-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100/80 dark:bg-slate-900/70"
          >
            <button
              type="button"
              role="tab"
              aria-selected={mode === 'sms'}
              onClick={() => {
                setValidationError(null);
                onModeChange('sms');
              }}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                mode === 'sms'
                  ? 'bg-white dark:bg-slate-800 text-blue-700 dark:text-cyan-300 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <MessageSquareText className="w-4 h-4" />
              <span>SMS &amp; Message</span>
            </button>

            <button
              type="button"
              role="tab"
              aria-selected={mode === 'email'}
              onClick={() => {
                setValidationError(null);
                onModeChange('email');
              }}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                mode === 'email'
                  ? 'bg-white dark:bg-slate-800 text-blue-700 dark:text-cyan-300 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <Mail className="w-4 h-4" />
              <span>Email Scanner</span>
            </button>

            <button
              type="button"
              role="tab"
              aria-selected={mode === 'url'}
              onClick={() => {
                setValidationError(null);
                onModeChange('url');
              }}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                mode === 'url'
                  ? 'bg-white dark:bg-slate-800 text-blue-700 dark:text-cyan-300 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <Globe className="w-4 h-4" />
              <span>URL Scanner</span>
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={onToggleSaveHistory}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 text-slate-700 dark:text-slate-300 hover:border-blue-500 dark:hover:border-cyan-500 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              title="Toggle whether scan summaries are saved locally in your browser"
            >
              <History className="w-3.5 h-3.5 text-blue-600 dark:text-cyan-400" />
              <span>History Storage: {saveHistoryEnabled ? 'On' : 'Off'}</span>
            </button>

            <button
              type="button"
              onClick={onToggleTheme}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 text-slate-700 dark:text-slate-300 hover:border-blue-500 dark:hover:border-cyan-500 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
            >
              {theme === 'dark' ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-400" />
                  <span>Light Mode</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 text-blue-600" />
                  <span>Dark Mode</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Main Glassmorphism Scanner Card */}
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/85 dark:bg-slate-900/65 backdrop-blur-md p-5 sm:p-8 shadow-sm">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-6 mb-6 border-b border-slate-200 dark:border-slate-800">
            <div>
              <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                {mode === 'sms' && 'SMS & Messaging Threat Scanner'}
                {mode === 'email' && 'Suspicious Email Inspector'}
                {mode === 'url' && 'Static URL & Domain Analyzer'}
              </h2>
              <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
                {mode === 'sms' &&
                  'Paste an SMS, WhatsApp, or direct message to check for smishing, urgency lures, and malicious links.'}
                {mode === 'email' &&
                  'Paste the email subject, sender address, and body to detect impersonation, credential harvesting, and BEC scams.'}
                {mode === 'url' &&
                  'Submit a website link for structural analysis. scam_shield never visits, opens, or executes submitted URLs.'}
              </p>
            </div>

            <div className="text-xs text-slate-500 dark:text-slate-400 shrink-0">
              {aiConfigured === true && (
                <span className="inline-flex items-center gap-1.5 text-emerald-700 dark:text-emerald-400 font-medium">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Gemini AI + ML Hybrid Ready</span>
                </span>
              )}
              {aiConfigured === false && (
                <span className="inline-flex items-center gap-1.5 text-amber-700 dark:text-amber-400 font-medium">
                  <Lock className="w-3.5 h-3.5" />
                  <span>Offline Baseline ML Mode (No external API key)</span>
                </span>
              )}
            </div>
          </div>

          {/* Sample Threat Selector Strip */}
          <div className="mb-5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-medium text-slate-500 dark:text-slate-400 mr-1">
                Load sample:
              </span>
              {modeSamples.map((sample) => (
                <button
                  key={sample.id}
                  type="button"
                  onClick={() => handleLoadSample(sample.id)}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium border border-slate-200 dark:border-slate-700/80 bg-slate-50 dark:bg-slate-800/70 text-slate-700 dark:text-slate-200 hover:border-blue-500 dark:hover:border-cyan-400 hover:text-blue-700 dark:hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  {sample.label} · {sample.categoryLabel}
                </button>
              ))}
            </div>
          </div>

          <form onSubmit={handleFormSubmit} className="space-y-4">
            {mode === 'email' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="email-sender"
                    className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5"
                  >
                    Sender Name / Email Address (Optional)
                  </label>
                  <input
                    id="email-sender"
                    type="text"
                    value={sender}
                    onChange={(e) => onSenderChange(e.target.value)}
                    placeholder="e.g. PayPal Support <alerts@mailer-verify99.xyz>"
                    maxLength={240}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080D1A] text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-cyan-400"
                  />
                </div>
                <div>
                  <label
                    htmlFor="email-subject"
                    className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5"
                  >
                    Email Subject Line (Optional)
                  </label>
                  <input
                    id="email-subject"
                    type="text"
                    value={subject}
                    onChange={(e) => onSubjectChange(e.target.value)}
                    placeholder="e.g. URGENT: Unauthorized transaction — Action Required"
                    maxLength={300}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080D1A] text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-cyan-400"
                  />
                </div>
              </div>
            )}

            {mode === 'url' ? (
              <div>
                <label
                  htmlFor="url-input"
                  className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5"
                >
                  Website URL to Inspect
                </label>
                <input
                  id="url-input"
                  type="text"
                  autoFocus
                  value={content}
                  onChange={(e) => {
                    setValidationError(null);
                    onContentChange(e.target.value);
                  }}
                  placeholder="https://example-login-verify.xyz/account"
                  maxLength={2000}
                  className="w-full px-4 py-3.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080D1A] font-mono text-sm text-slate-900 dark:text-cyan-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-cyan-400"
                />
                <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">
                  Safety guarantee: URLs are parsed statically for typosquatting, homographs, IP hosts, and path patterns. We never connect to or render external sites.
                </p>
              </div>
            ) : (
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label
                    htmlFor="message-input"
                    className="block text-xs font-medium text-slate-700 dark:text-slate-300"
                  >
                    {mode === 'sms' ? 'Suspicious Message Content' : 'Email Body Content'}
                  </label>
                  <span className="font-mono text-xs tabular-nums text-slate-400 dark:text-slate-500">
                    {content.length} / 8000
                  </span>
                </div>
                <textarea
                  id="message-input"
                  rows={6}
                  autoFocus
                  value={content}
                  onChange={(e) => {
                    setValidationError(null);
                    onContentChange(e.target.value);
                  }}
                  placeholder={
                    mode === 'sms'
                      ? 'Paste the SMS, WhatsApp, or social DM text here...'
                      : 'Paste the full email text here...'
                  }
                  maxLength={8000}
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#080D1A] text-sm sm:text-base text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 leading-relaxed focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-cyan-400"
                />
              </div>
            )}

            {displayError && (
              <div
                role="alert"
                className="flex items-start gap-2.5 p-3.5 rounded-xl border border-rose-300 dark:border-rose-800/80 bg-rose-50 dark:bg-rose-950/40 text-sm text-rose-800 dark:text-rose-200"
              >
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                <span>{displayError}</span>
              </div>
            )}

            <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="submit"
                  disabled={isScanning}
                  className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold bg-blue-600 hover:bg-blue-700 disabled:opacity-60 dark:bg-cyan-500 dark:hover:bg-cyan-400 text-white dark:text-slate-950 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <SearchCheck className="w-4 h-4" />
                  <span>
                    {isScanning
                      ? 'Analyzing Submission...'
                      : mode === 'sms'
                        ? 'Analyze Message'
                        : mode === 'email'
                          ? 'Analyze Email'
                          : 'Analyze URL'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setValidationError(null);
                    onClear();
                  }}
                  disabled={isScanning}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Eraser className="w-4 h-4" />
                  <span>Clear</span>
                </button>
              </div>

              <p className="text-xs text-slate-500 dark:text-slate-400">
                Server never logs submitted message text · Passive analysis only
              </p>
            </div>
          </form>

          {/* Loading Skeleton */}
          {isScanning && (
            <div
              aria-live="polite"
              className="mt-6 pt-6 border-t border-slate-200 dark:border-slate-800 space-y-4 animate-pulse"
            >
              <div className="flex items-center justify-between">
                <div className="h-5 w-48 rounded bg-slate-200 dark:bg-slate-800" />
                <div className="h-5 w-28 rounded bg-slate-200 dark:bg-slate-800" />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="h-24 rounded-xl bg-slate-200/80 dark:bg-slate-800/70" />
                <div className="h-24 rounded-xl bg-slate-200/80 dark:bg-slate-800/70 md:col-span-2" />
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
