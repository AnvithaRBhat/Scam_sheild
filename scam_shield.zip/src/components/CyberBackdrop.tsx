export function CyberBackdrop() {
  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 -z-10 overflow-hidden"
    >
      <div className="absolute inset-0 cyber-grid-bg opacity-70 dark:opacity-100" />
      <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[900px] h-[420px] rounded-full bg-blue-500/8 dark:bg-cyan-500/8 blur-3xl" />
      <div className="absolute bottom-0 right-0 w-[640px] h-[360px] rounded-full bg-emerald-500/5 dark:bg-blue-600/8 blur-3xl" />
    </div>
  );
}
