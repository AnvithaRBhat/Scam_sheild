import { Moon, Sun } from 'lucide-react';
import { AppPage } from './Navbar';
import { ScamShieldLogo } from './ScamShieldLogo';

interface FooterProps {
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  onNavigate: (page: AppPage) => void;
}

export function Footer({ theme, onToggleTheme, onNavigate }: FooterProps) {
  return (
    <footer className="border-t border-slate-200 dark:border-slate-800/80 bg-white/70 dark:bg-[#050811]/90 py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6 pb-8 border-b border-slate-200 dark:border-slate-800">
          <div>
            <button
              type="button"
              onClick={() => onNavigate('home')}
              className="flex items-center gap-2.5 mb-2 cursor-pointer"
            >
              <ScamShieldLogo className="w-7 h-7" />
              <span className="font-display text-lg font-bold tracking-tight text-slate-900 dark:text-white">
                scam_shield
              </span>
            </button>
            <p className="text-sm text-slate-600 dark:text-slate-300">
              Don&apos;t just detect scams. Understand them. Prevent them. Stay protected.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-5 text-sm text-slate-600 dark:text-slate-300">
            <button
              type="button"
              onClick={() => onNavigate('scanner')}
              className="hover:text-blue-600 dark:hover:text-cyan-300 transition-colors cursor-pointer"
            >
              Scanner
            </button>
            <button
              type="button"
              onClick={() => onNavigate('how-it-works')}
              className="hover:text-blue-600 dark:hover:text-cyan-300 transition-colors cursor-pointer"
            >
              How It Works
            </button>
            <button
              type="button"
              onClick={() => onNavigate('threat-guide')}
              className="hover:text-blue-600 dark:hover:text-cyan-300 transition-colors cursor-pointer"
            >
              Threat Guide
            </button>
            <button
              type="button"
              onClick={() => onNavigate('history')}
              className="hover:text-blue-600 dark:hover:text-cyan-300 transition-colors cursor-pointer"
            >
              History
            </button>
            <button
              type="button"
              onClick={() => onNavigate('privacy')}
              className="hover:text-blue-600 dark:hover:text-cyan-300 transition-colors cursor-pointer"
            >
              Privacy Model
            </button>
            <button
              type="button"
              onClick={onToggleTheme}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 text-xs font-medium hover:border-blue-500 dark:hover:border-cyan-400 transition-colors cursor-pointer"
            >
              {theme === 'dark' ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
              <span>{theme === 'dark' ? 'Light Mode' : 'Dark Mode'}</span>
            </button>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-xs text-slate-500 dark:text-slate-400">
          <p>
            scam_shield provides preliminary, explainable risk assessments for educational and defensive awareness. No automated detector guarantees 100% accuracy.
          </p>
          <p className="shrink-0">
            &copy; {new Date().getFullYear()} scam_shield
          </p>
        </div>
      </div>
    </footer>
  );
}
