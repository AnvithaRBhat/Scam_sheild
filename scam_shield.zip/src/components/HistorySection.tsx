import { useState } from 'react';
import { ArrowUpRight, SearchCheck, Trash2 } from 'lucide-react';
import { ScanHistoryItem, ScanMode, ScanResult } from '../types/scamshield';

interface HistorySectionProps {
  history: ScanHistoryItem[];
  saveHistoryEnabled: boolean;
  onToggleSaveHistory: () => void;
  onClearHistory: () => void;
  onSelectHistoryItem: (result: ScanResult) => void;
  onStartScanning: () => void;
}

export function HistorySection({
  history,
  saveHistoryEnabled,
  onToggleSaveHistory,
  onClearHistory,
  onSelectHistoryItem,
  onStartScanning,
}: HistorySectionProps) {
  const [filterMode, setFilterMode] = useState<'all' | ScanMode>('all');

  const filtered =
    filterMode === 'all' ? history : history.filter((item) => item.mode === filterMode);

  return (
    <section id="history" className="py-10 lg:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4">
          <div>
            <p className="text-xs font-medium text-blue-600 dark:text-cyan-400 mb-2">
              Browser-Only Scan Log
            </p>
            <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
              Scan History &amp; Past Verdicts
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-300 mt-2 max-w-2xl">
              Review the messages, emails, and URLs you have checked along with their spam/phishing classification and risk score. Saved only in your browser when enabled.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={onToggleSaveHistory}
              className="px-3.5 py-2 rounded-xl text-xs font-medium border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:border-blue-500 dark:hover:border-cyan-400 transition-colors cursor-pointer"
            >
              Local History: {saveHistoryEnabled ? 'Enabled' : 'Disabled'}
            </button>

            {history.length > 0 && (
              <button
                type="button"
                onClick={onClearHistory}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium border border-rose-300 dark:border-rose-900/70 text-rose-700 dark:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear History</span>
              </button>
            )}
          </div>
        </div>

        {/* History Filter & Table */}
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/85 dark:bg-slate-900/65 overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div className="inline-flex items-center gap-1 p-1 rounded-lg bg-slate-100 dark:bg-slate-800/80">
              {(['all', 'sms', 'email', 'url'] as const).map((tab) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setFilterMode(tab)}
                  className={`px-3 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                    filterMode === tab
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  {tab === 'all' ? 'All Scans' : tab.toUpperCase()}
                </button>
              ))}
            </div>
            <span className="font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
              {filtered.length} saved item(s)
            </span>
          </div>

          {filtered.length === 0 ? (
            <div className="p-12 text-center space-y-4">
              <div>
                <p className="text-base font-semibold text-slate-800 dark:text-slate-200">
                  {saveHistoryEnabled
                    ? 'No scans saved yet in this view.'
                    : 'Local scan history saving is currently turned off.'}
                </p>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                  Open the Scanner to inspect a message, email, or link and see its full explanation here.
                </p>
              </div>
              <button
                type="button"
                onClick={onStartScanning}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold bg-blue-600 hover:bg-blue-700 dark:bg-cyan-500 dark:hover:bg-cyan-400 text-white dark:text-slate-950 transition-colors cursor-pointer"
              >
                <SearchCheck className="w-4 h-4" />
                <span>Go to Scanner</span>
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
                    <th className="py-3 px-5 font-medium">Date</th>
                    <th className="py-3 px-4 font-medium">Channel</th>
                    <th className="py-3 px-4 font-medium">Message / Input Preview</th>
                    <th className="py-3 px-4 font-medium">Verdict</th>
                    <th className="py-3 px-4 font-medium text-right">Risk Score</th>
                    <th className="py-3 px-5 font-medium text-right">Full Report</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {filtered.map((item) => (
                    <tr
                      key={item.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      <td className="py-3.5 px-5 font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400 whitespace-nowrap">
                        {new Date(item.timestamp).toLocaleDateString()} ·{' '}
                        {new Date(item.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>
                      <td className="py-3.5 px-4 font-mono text-xs text-slate-700 dark:text-slate-300 whitespace-nowrap">
                        {item.mode.toUpperCase()}
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 dark:text-slate-200 max-w-md truncate">
                        {item.preview}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap text-xs font-semibold">
                        <span
                          className={
                            item.riskLevel === 'High'
                              ? 'text-rose-700 dark:text-rose-400'
                              : item.riskLevel === 'Medium'
                                ? 'text-amber-700 dark:text-amber-400'
                                : 'text-emerald-700 dark:text-emerald-400'
                          }
                        >
                          {item.classification}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono text-xs tabular-nums font-semibold text-slate-900 dark:text-white whitespace-nowrap">
                        {item.riskScore}/100
                      </td>
                      <td className="py-3.5 px-5 text-right whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => onSelectHistoryItem(item.result)}
                          className="inline-flex items-center gap-1 text-xs font-medium text-blue-600 dark:text-cyan-400 hover:underline cursor-pointer"
                        >
                          <span>View Report</span>
                          <ArrowUpRight className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
