interface ScamShieldLogoProps {
  className?: string;
}

export function ScamShieldLogo({ className = 'w-8 h-8' }: ScamShieldLogoProps) {
  return (
    <svg
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <path
        d="M20 3L6 8.6V18.8C6 27.6 11.96 35.64 20 38C28.04 35.64 34 27.6 34 18.8V8.6L20 3Z"
        className="fill-blue-600/15 stroke-blue-600 dark:fill-cyan-500/15 dark:stroke-cyan-400"
        strokeWidth="2"
        strokeLinejoin="round"
      />
      <path
        d="M20 8.5L11 12.1V18.7C11 24.75 14.84 30.28 20 32.1C25.16 30.28 29 24.75 29 18.7V12.1L20 8.5Z"
        className="stroke-blue-500/50 dark:stroke-blue-400/60"
        strokeWidth="1.25"
        strokeLinejoin="round"
      />
      {/* AI neural circuit core inside shield */}
      <path
        d="M20 14.5V25.5M14.8 18.2L20 20.5L25.2 18.2M16.2 23.8L20 20.5L23.8 23.8"
        className="stroke-blue-700 dark:stroke-cyan-300"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="20" cy="14" r="1.75" className="fill-emerald-500 dark:fill-emerald-400" />
      <circle cx="14.5" cy="18" r="1.4" className="fill-blue-600 dark:fill-cyan-300" />
      <circle cx="25.5" cy="18" r="1.4" className="fill-blue-600 dark:fill-cyan-300" />
      <circle cx="20" cy="26" r="1.5" className="fill-blue-600 dark:fill-cyan-300" />
    </svg>
  );
}
