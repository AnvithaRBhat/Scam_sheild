import { ReactNode, useMemo, useState } from 'react';
import {
  AlertTriangle,
  Check,
  CheckCircle2,
  Copy,
  Download,
  Info,
  RotateCcw,
  ShieldAlert,
  ShieldCheck,
  ShieldQuestion,
} from 'lucide-react';
import { ScanResult, SuspiciousPattern } from '../types/scamshield';
import { UnderstandThreatPanel } from './UnderstandThreatPanel';

interface ResultsDashboardProps {
  result: ScanResult;
  onScanAgain: () => void;
}

interface HighlightSegment {
  text: string;
  pattern?: SuspiciousPattern;
}

function buildHighlightedSegments(
  text: string,
  patterns: SuspiciousPattern[]
): HighlightSegment[] {
  if (!text || patterns.length === 0) return [{ text }];

  const lowerText = text.toLowerCase();
  const spans: { start: number; end: number; pattern: SuspiciousPattern }[] = [];

  for (const pattern of patterns) {
    const needle = pattern.phrase.trim().toLowerCase();
    if (needle.length < 2) continue;

    let searchFrom = 0;
    while (searchFrom < lowerText.length) {
      const idx = lowerText.indexOf(needle, searchFrom);
      if (idx === -1) break;
      const end = idx + needle.length;
      const overlaps = spans.some((s) => idx < s.end && end > s.start);
      if (!overlaps) {
        spans.push({ start: idx, end, pattern });
      }
      searchFrom = end;
    }
  }

  if (spans.length === 0) return [{ text }];
  spans.sort((a, b) => a.start - b.start);

  const segments: HighlightSegment[] = [];
  let cursor = 0;
  for (const span of spans) {
    if (span.start > cursor) {
      segments.push({ text: text.slice(cursor, span.start) });
    }
    segments.push({ text: text.slice(span.start, span.end), pattern: span.pattern });
    cursor = span.end;
  }
  if (cursor < text.length) {
    segments.push({ text: text.slice(cursor) });
  }
  return segments;
}

export function ResultsDashboard({ result, onScanAgain }: ResultsDashboardProps) {
  const [selectedPattern, setSelectedPattern] = useState<SuspiciousPattern | null>(
    result.suspiciousPatterns[0] ?? null
  );
  const [copied, setCopied] = useState(false);

  const segments = useMemo(
    () => buildHighlightedSegments(result.analyzedText, result.suspiciousPatterns),
    [result.analyzedText, result.suspiciousPatterns]
  );

  const detectedEvidence = result.detailedReasoning.filter(
    (r) => r.certainty === 'detected-evidence'
  );
  const uncertainIndications = result.detailedReasoning.filter(
    (r) => r.certainty === 'uncertain-indication'
  );

  const statusMeta = (() => {
    if (result.riskLevel === 'High' || result.classification === 'Potential Phishing') {
      return {
        colorText: 'text-rose-700 dark:text-rose-400',
        strokeColor: '#E11D48',
        borderTone: 'border-rose-200 dark:border-rose-900/70',
        surfaceTone: 'bg-rose-50/70 dark:bg-rose-950/25',
        icon: <ShieldAlert className="w-7 h-7 text-rose-600 dark:text-rose-400 shrink-0" />,
      };
    }
    if (result.riskLevel === 'Medium' || result.classification === 'Suspicious' || result.classification === 'Spam') {
      return {
        colorText: 'text-amber-700 dark:text-amber-400',
        strokeColor: '#D97706',
        borderTone: 'border-amber-200 dark:border-amber-900/70',
        surfaceTone: 'bg-amber-50/70 dark:bg-amber-950/25',
        icon: <AlertTriangle className="w-7 h-7 text-amber-600 dark:text-amber-400 shrink-0" />,
      };
    }
    return {
      colorText: 'text-emerald-700 dark:text-emerald-400',
      strokeColor: '#10B981',
      borderTone: 'border-emerald-200 dark:border-emerald-900/70',
      surfaceTone: 'bg-emerald-50/70 dark:bg-emerald-950/25',
      icon: <ShieldCheck className="w-7 h-7 text-emerald-600 dark:text-emerald-400 shrink-0" />,
    };
  })();

  // SVG gauge geometry (semicircle / 240 deg arc)
  const radius = 44;
  const circumference = 2 * Math.PI * radius;
  const progressOffset = circumference - (result.riskScore / 100) * circumference;

  const buildTextReport = () => {
    const lines = [
      'scam_shield — SECURITY ANALYSIS REPORT',
      '========================================',
      `Scan ID: ${result.id}`,
      `Date: ${new Date(result.timestamp).toLocaleString()}`,
      `Channel: ${result.mode.toUpperCase()}`,
      `Classification: ${result.classification}`,
      `Estimated Risk Level: ${result.riskLevel} (${result.riskScore}/100)`,
      `Disclaimer: ${result.riskDisclaimer}`,
      `Engine: ${result.engineNotice}`,
      '',
      'SUMMARY',
      result.summary,
      '',
      'DETECTED EVIDENCE & REASONING',
      ...result.detailedReasoning.map(
        (r, i) => `${i + 1}. [${r.certainty === 'detected-evidence' ? 'Detected Evidence' : 'Uncertain Indication'}] ${r.title}: ${r.detail}`
      ),
      '',
      'FLAGGED PATTERNS',
      ...(result.suspiciousPatterns.length > 0
        ? result.suspiciousPatterns.map(
            (p) => `- "${p.phrase}" (${p.category} · ${p.severity}): ${p.explanation}`
          )
        : ['- None detected']),
      '',
      'RECOMMENDED ACTIONS',
      ...result.recommendedActions.map((a, i) => `${i + 1}. ${a}`),
      '',
      'UNDERSTAND THE THREAT',
      `Type: ${result.understandTheThreat.scamType}`,
      `How it works: ${result.understandTheThreat.howItWorks}`,
      `Attacker goal: ${result.understandTheThreat.attackerGoal}`,
    ];
    return lines.join('\n');
  };

  const handleDownloadTxt = () => {
    const blob = new Blob([buildTextReport()], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `scamshield-report-${result.id.slice(0, 8)}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadJson = () => {
    const blob = new Blob([JSON.stringify(result, null, 2)], {
      type: 'application/json;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `scamshield-report-${result.id.slice(0, 8)}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleCopySummary = async () => {
    try {
      await navigator.clipboard.writeText(buildTextReport());
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  const renderHighlightedNode = (seg: HighlightSegment, idx: number): ReactNode => {
    if (!seg.pattern) {
      return <span key={idx}>{seg.text}</span>;
    }
    const sevClass =
      seg.pattern.severity === 'high'
        ? 'bg-rose-500/20 text-rose-900 dark:text-rose-200 border-b-2 border-rose-500'
        : seg.pattern.severity === 'medium'
          ? 'bg-amber-500/20 text-amber-900 dark:text-amber-200 border-b-2 border-amber-500'
          : 'bg-cyan-500/20 text-cyan-900 dark:text-cyan-200 border-b-2 border-cyan-500';

    return (
      <button
        key={idx}
        type="button"
        onClick={() => setSelectedPattern(seg.pattern ?? null)}
        className={`inline px-1 py-0.5 rounded-sm font-medium cursor-pointer transition-opacity hover:opacity-85 ${sevClass}`}
        title={`${seg.pattern.category}: ${seg.pattern.explanation}`}
      >
        {seg.text}
      </button>
    );
  };

  return (
    <section
      id="results"
      aria-label="Scan Analysis Results"
      className="pb-12 space-y-6"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {/* Top Verdict & Risk Score Header Card */}
        <div
          className={`rounded-2xl border ${statusMeta.borderTone} bg-white/90 dark:bg-slate-900/75 backdrop-blur-md p-6 sm:p-8`}
        >
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
            {/* Risk Score Gauge + Classification */}
            <div className="flex flex-col sm:flex-row sm:items-center gap-6">
              <div className="relative w-28 h-28 shrink-0 flex items-center justify-center">
                <svg className="w-28 h-28 -rotate-90" viewBox="0 0 104 104" aria-hidden="true">
                  <circle
                    cx="52"
                    cy="52"
                    r={radius}
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="8"
                    className="text-slate-200 dark:text-slate-800"
                  />
                  <circle
                    cx="52"
                    cy="52"
                    r={radius}
                    fill="none"
                    stroke={statusMeta.strokeColor}
                    strokeWidth="8"
                    strokeLinecap="round"
                    strokeDasharray={circumference}
                    strokeDashoffset={progressOffset}
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="font-mono text-2xl font-bold tabular-nums text-slate-900 dark:text-white">
                    {result.riskScore}
                  </span>
                  <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                    / 100
                  </span>
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2.5 mb-2">
                  {statusMeta.icon}
                  <h2 className={`font-display text-2xl sm:text-3xl font-bold ${statusMeta.colorText}`}>
                    {result.classification}
                  </h2>
                </div>

                <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs sm:text-sm text-slate-600 dark:text-slate-300 mb-3">
                  <span className="font-semibold">Risk Level: {result.riskLevel}</span>
                  <span aria-hidden="true">·</span>
                  <span>Channel: {result.mode.toUpperCase()}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">
                    ML Threat Signal: {result.mlMetrics.spamProbability}%
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>
                    {result.analysisEngine === 'gemini-ai-hybrid'
                      ? 'Gemini AI + Lexical/ML'
                      : 'Baseline ML Engine'}
                  </span>
                </div>

                <p className="text-sm sm:text-base text-slate-700 dark:text-slate-200 max-w-2xl leading-relaxed">
                  {result.summary}
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-2.5 shrink-0">
              <button
                type="button"
                onClick={handleCopySummary}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/80 text-slate-700 dark:text-slate-200 hover:border-blue-500 dark:hover:border-cyan-400 transition-colors cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Report'}</span>
              </button>

              <button
                type="button"
                onClick={handleDownloadTxt}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/80 text-slate-700 dark:text-slate-200 hover:border-blue-500 dark:hover:border-cyan-400 transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Report (.txt)</span>
              </button>

              <button
                type="button"
                onClick={handleDownloadJson}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/80 text-slate-700 dark:text-slate-200 hover:border-blue-500 dark:hover:border-cyan-400 transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>JSON</span>
              </button>

              <button
                type="button"
                onClick={onScanAgain}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-blue-600 hover:bg-blue-700 dark:bg-cyan-500 dark:hover:bg-cyan-400 text-white dark:text-slate-950 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Scan Again</span>
              </button>
            </div>
          </div>

          {/* Transparent Disclaimer & Engine Provenance */}
          <div className={`mt-6 p-4 rounded-xl border ${statusMeta.borderTone} ${statusMeta.surfaceTone} flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-xs text-slate-700 dark:text-slate-300`}>
            <div className="flex items-start gap-2">
              <Info className="w-4 h-4 mt-0.5 shrink-0 text-blue-600 dark:text-cyan-400" />
              <span>
                <strong>Estimated Score Notice:</strong> {result.riskDisclaimer} {result.confidenceNote}
              </span>
            </div>
            <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400 shrink-0">
              {result.engineNotice}
            </span>
          </div>
        </div>

        {/* Row 2: Highlighted Suspicious Text + Pattern Inspector */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/85 dark:bg-slate-900/65 p-6">
            <div className="flex items-center justify-between gap-4 mb-4">
              <h3 className="font-display text-lg font-semibold text-slate-900 dark:text-white">
                Inspected Content &amp; Highlighted Indicators
              </h3>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                {result.suspiciousPatterns.length} flagged span(s)
              </span>
            </div>

            {(result.sender || result.subject) && (
              <div className="mb-4 pb-4 border-b border-slate-200 dark:border-slate-800 space-y-1.5 text-xs sm:text-sm">
                {result.sender && (
                  <p className="text-slate-700 dark:text-slate-300">
                    <span className="font-semibold text-slate-500 dark:text-slate-400 mr-2">From:</span>
                    <span className="font-mono break-all">{result.sender}</span>
                  </p>
                )}
                {result.subject && (
                  <p className="text-slate-700 dark:text-slate-300">
                    <span className="font-semibold text-slate-500 dark:text-slate-400 mr-2">Subject:</span>
                    <span>{result.subject}</span>
                  </p>
                )}
              </div>
            )}

            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#080D1A] text-sm sm:text-base text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-wrap break-words font-normal">
              {segments.map((seg, i) => renderHighlightedNode(seg, i))}
            </div>

            {selectedPattern && (
              <div className="mt-4 p-4 rounded-xl border border-blue-200 dark:border-cyan-900/70 bg-blue-50/70 dark:bg-cyan-950/25">
                <p className="text-xs font-medium text-blue-700 dark:text-cyan-300 mb-1">
                  Selected Highlight · {selectedPattern.category} · Severity: {selectedPattern.severity}
                </p>
                <p className="font-mono text-xs text-slate-900 dark:text-white mb-1.5 break-all">
                  &ldquo;{selectedPattern.phrase}&rdquo;
                </p>
                <p className="text-sm text-slate-700 dark:text-slate-300">
                  {selectedPattern.explanation}
                </p>
              </div>
            )}
          </div>

          {/* Right Column: Suspicious Pattern List & Recommended Actions */}
          <div className="lg:col-span-5 space-y-6">
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/85 dark:bg-slate-900/65 p-6">
              <h3 className="font-display text-lg font-semibold text-slate-900 dark:text-white mb-4">
                Recommended Actions
              </h3>
              <ul className="space-y-3">
                {result.recommendedActions.map((action, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 text-sm text-slate-700 dark:text-slate-200">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 dark:text-cyan-400 mt-0.5 shrink-0" />
                    <span>{action}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/85 dark:bg-slate-900/65 p-6">
              <h3 className="font-display text-lg font-semibold text-slate-900 dark:text-white mb-3">
                Identified Patterns ({result.suspiciousPatterns.length})
              </h3>
              {result.suspiciousPatterns.length === 0 ? (
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  No specific high-risk phrases or structural anomalies were flagged in this submission.
                </p>
              ) : (
                <div className="space-y-2.5">
                  {result.suspiciousPatterns.map((p, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSelectedPattern(p)}
                      className={`w-full text-left p-3 rounded-xl border transition-colors cursor-pointer ${
                        selectedPattern?.phrase === p.phrase
                          ? 'border-blue-500 dark:border-cyan-400 bg-blue-50/50 dark:bg-cyan-950/30'
                          : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 text-xs mb-1">
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          {p.category}
                        </span>
                        <span className="font-mono text-slate-500 dark:text-slate-400">
                          {p.severity} · {p.source}
                        </span>
                      </div>
                      <p className="font-mono text-xs text-blue-700 dark:text-cyan-300 truncate">
                        {p.phrase}
                      </p>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Row 3: Detailed Reasoning — Evidence vs Uncertain Indications */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/85 dark:bg-slate-900/65 p-6">
            <div className="flex items-center gap-2 mb-4">
              <ShieldCheck className="w-5 h-5 text-blue-600 dark:text-cyan-400" />
              <h3 className="font-display text-lg font-semibold text-slate-900 dark:text-white">
                Detected Evidence ({detectedEvidence.length})
              </h3>
            </div>
            {detectedEvidence.length === 0 ? (
              <p className="text-sm text-slate-600 dark:text-slate-400">
                No direct concrete threat evidence was observed.
              </p>
            ) : (
              <div className="space-y-4">
                {detectedEvidence.map((item, idx) => (
                  <div
                    key={idx}
                    className="pb-4 last:pb-0 border-b last:border-b-0 border-slate-200 dark:border-slate-800"
                  >
                    <h4 className="text-sm font-semibold text-slate-900 dark:text-white mb-1">
                      {item.title}
                    </h4>
                    <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                      {item.detail}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/85 dark:bg-slate-900/65 p-6">
            <div className="flex items-center gap-2 mb-4">
              <ShieldQuestion className="w-5 h-5 text-amber-600 dark:text-amber-400" />
              <h3 className="font-display text-lg font-semibold text-slate-900 dark:text-white">
                Uncertain Indications &amp; Context ({uncertainIndications.length})
              </h3>
            </div>
            {uncertainIndications.length === 0 ? (
              <p className="text-sm text-slate-600 dark:text-slate-400">
                All findings in this scan were backed by direct lexical or structural evidence rather than ambiguous cues.
              </p>
            ) : (
              <div className="space-y-4">
                {uncertainIndications.map((item, idx) => (
                  <div
                    key={idx}
                    className="pb-4 last:pb-0 border-b last:border-b-0 border-slate-200 dark:border-slate-800"
                  >
                    <h4 className="text-sm font-semibold text-slate-900 dark:text-white mb-1">
                      {item.title}
                    </h4>
                    <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                      {item.detail}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Optional URL Structural Diagnostics Table */}
        {result.urlDiagnostics && (
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/85 dark:bg-slate-900/65 p-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-4">
              <div>
                <h3 className="font-display text-lg font-semibold text-slate-900 dark:text-white">
                  URL Structural Inspection
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-mono mt-0.5 break-all">
                  Host: {result.urlDiagnostics.hostname} · Subdomains: {result.urlDiagnostics.subdomainCount} · Entropy: {result.urlDiagnostics.entropy}
                </p>
              </div>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                Note: HTTPS encryption never guarantees domain legitimacy
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
                    <th className="py-2.5 pr-4 font-medium">Inspection Check</th>
                    <th className="py-2.5 px-4 font-medium">Outcome</th>
                    <th className="py-2.5 pl-4 font-medium">Technical Detail</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {result.urlDiagnostics.structuralChecks.map((chk, idx) => (
                    <tr key={idx}>
                      <td className="py-3 pr-4 font-medium text-slate-900 dark:text-slate-100 whitespace-nowrap">
                        {chk.label}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap font-mono text-xs">
                        {chk.status === 'pass' && (
                          <span className="text-emerald-700 dark:text-emerald-400 font-semibold">
                            PASS
                          </span>
                        )}
                        {chk.status === 'warn' && (
                          <span className="text-amber-700 dark:text-amber-400 font-semibold">
                            CAUTION
                          </span>
                        )}
                        {chk.status === 'fail' && (
                          <span className="text-rose-700 dark:text-rose-400 font-semibold">
                            FLAGGED
                          </span>
                        )}
                      </td>
                      <td className="py-3 pl-4 text-slate-600 dark:text-slate-300">
                        {chk.detail}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Unique Feature: Understand the Threat */}
        <UnderstandThreatPanel
          classification={result.classification}
          data={result.understandTheThreat}
        />
      </div>
    </section>
  );
}
