import { ScanMode } from '../types/scamshield';

export interface SampleCase {
  id: string;
  mode: ScanMode;
  label: string;
  categoryLabel: string;
  subject?: string;
  sender?: string;
  content: string;
}

export const SAMPLE_CASES: SampleCase[] = [
  {
    id: 'sms-bank-lock',
    mode: 'sms',
    label: 'Bank Account Suspension SMS',
    categoryLabel: 'Smishing Pattern',
    content:
      'URGENT ALERT: Your Chase Bank debit card has been temporarily suspended due to unusual activity. Verify your identity within 12 hours to avoid permanent closure: https://chase-security-verify.xyz/auth/login',
  },
  {
    id: 'sms-parcel-fee',
    mode: 'sms',
    label: 'Unpaid Parcel Delivery Fee',
    categoryLabel: 'Delivery Scam',
    content:
      'USPS Notice: Your package #US99412 cannot be delivered due to an incomplete address and $2.95 redelivery fee. Update your details immediately at http://usps-track-redelivery.top/pay',
  },
  {
    id: 'sms-prize-spam',
    mode: 'sms',
    label: 'Unexpected Gift Card Prize',
    categoryLabel: 'Promotional Spam',
    content:
      'Congratulations! You were randomly selected to claim a $500 Walmart reward card today only. Reply YES or tap bit.ly/claim-500-now before midnight to claim your prize!',
  },
  {
    id: 'sms-legit-appt',
    mode: 'sms',
    label: 'Legitimate Dental Reminder',
    categoryLabel: 'Safe Reference',
    content:
      'Hi Maya, this is a friendly reminder from Oakridge Dental that your cleaning appointment is scheduled for Thursday at 10:30 AM. Reply C to confirm or call our office directly if you need to reschedule.',
  },
  {
    id: 'email-paypal-impersonation',
    mode: 'email',
    label: 'PayPal Billing Impersonation',
    categoryLabel: 'Phishing Email',
    sender: 'PayPal Resolution Center <security-alerts@mailer-verify99.xyz>',
    subject: 'URGENT: Unauthorized transaction of $489.00 — Action Required',
    content:
      'Dear Customer,\n\nWe noticed a login attempt and an unauthorized payment of $489.00 from your PayPal account. If you did not authorize this charge, your account will be locked permanently within 24 hours.\n\nPlease verify your password, date of birth, and linked card details immediately using the secure portal below:\nhttps://paypa1-resolution-desk.xyz/account/verify\n\nThank you,\nPayPal Account Security Team',
  },
  {
    id: 'email-ceo-giftcard',
    mode: 'email',
    label: 'Executive Gift Card Request',
    categoryLabel: 'BEC / Impersonation',
    sender: 'David Chen (CEO) <dchen.executive.office@gmail.com>',
    subject: 'Quick confidential favor before my flight',
    content:
      'Are you at your desk right now? I am stuck in a board meeting and cannot take calls. I need you to purchase 6 Apple Gift Cards ($100 each) for a client appreciation surprise today. Please scratch the backs and email me the PIN codes ASAP. I will have finance reimburse you first thing tomorrow. Keep this discreet.',
  },
  {
    id: 'email-legit-receipt',
    mode: 'email',
    label: 'Legitimate Library Hold Notice',
    categoryLabel: 'Safe Reference',
    sender: 'Seattle Public Library <notices@spl.org>',
    subject: 'Your requested book is ready for pickup',
    content:
      'Hello,\n\nThe item you placed on hold ("Designing Data-Intensive Applications") is now available at the Central Library hold shelf through November 20.\n\nPlease bring your library card when picking up. You can manage your holds anytime by visiting spl.org in your browser.\n\nSeattle Public Library',
  },
  {
    id: 'url-typosquat',
    mode: 'url',
    label: 'Brand Typosquat Domain',
    categoryLabel: 'High-Risk URL',
    content: 'https://login.micros0ft-account-verify.xyz/oauth2/signin?session=expired',
  },
  {
    id: 'url-ip-phish',
    mode: 'url',
    label: 'Raw IP Address Login Link',
    categoryLabel: 'Suspicious URL',
    content: 'http://185.199.108.153:8080/banking/secure-update/verify.php?user=confirm',
  },
  {
    id: 'url-legit-gov',
    mode: 'url',
    label: 'Official Consumer Guidance URL',
    categoryLabel: 'Safe Reference',
    content: 'https://consumer.ftc.gov/articles/how-recognize-and-avoid-phishing-scams',
  },
];
